"use strict";
(() => {
  // shared/catalog.ts
  var ITEMS = [
    { id: "sunflower", kind: "food", price: 4, power: 15 },
    { id: "carrot", kind: "food", price: 8, power: 25 },
    { id: "yogurt", kind: "food", price: 14, power: 40 },
    { id: "chew", kind: "toy", price: 20, power: 6 },
    { id: "ball", kind: "toy", price: 30, power: 9 },
    { id: "tunnel", kind: "toy", price: 45, power: 12 },
    { id: "acorn", kind: "hat", price: 25, colors: ["#8a5a2b", "#c98b45"] },
    { id: "beanie", kind: "hat", price: 35, colors: ["#3b7dd8", "#f2f2f2"] },
    { id: "party", kind: "hat", price: 50, colors: ["#e0457b", "#ffd447"] },
    { id: "crown", kind: "hat", price: 90, colors: ["#f2b705", "#fff1a8"] },
    { id: "mint", kind: "wheel", price: 30, colors: ["#3fb68b", "#bff0dc"] },
    { id: "sunset", kind: "wheel", price: 45, colors: ["#e8743b", "#ffd0a8"] },
    { id: "golden", kind: "wheel", price: 120, colors: ["#d4a017", "#fff0a0"] }
  ];
  var DEFAULT_WHEEL_COLORS = ["#8c8c96", "#d9d9e0"];
  function itemById(id) {
    return ITEMS.find((i) => i.id === id);
  }

  // shared/art.ts
  var PAL = {
    o: "#e39a4b",
    // fur
    O: "#c9762f",
    // fur shade
    c: "#fbe3c0",
    // belly
    p: "#f2a3a8",
    // ear and paw pink
    k: "#2b1d14",
    // eye
    w: "#ffffff",
    // eye shine
    n: "#e86f86"
    // nose
  };
  var OUTLINE = "#4a2a12";
  var BODY = [
    "..........oo....",
    ".........oppo...",
    "....ooooooooo...",
    "...ooooooooooo..",
    "..OoooooooookwO.",
    "..Ooooooooookkon",
    ".OOoocccccccooo.",
    ".OOocccccccccoo.",
    ".OOocccccccccco.",
    "..OOccccccccoo.."
  ];
  var FEET_A = ["...pp.....pp....", "................"];
  var FEET_B = ["....pp...pp.....", "................"];
  var FEET_SIT = ["..pppp...pppp...", "................"];
  var SPRITE_W = 28;
  var SPRITE_H = 26;
  function px(ctx, x, y, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, 1, 1);
  }
  function drawMap(ctx, rows, ox, oy, palette, flip = false) {
    const w = rows[0].length;
    const filled = /* @__PURE__ */ new Set();
    rows.forEach(
      (row, y) => [...row].forEach((ch, x) => {
        if (ch !== ".") filled.add(`${flip ? w - 1 - x : x},${y}`);
      })
    );
    for (const key of filled) {
      const [x, y] = key.split(",").map(Number);
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        if (!filled.has(`${x + dx},${y + dy}`)) px(ctx, ox + x + dx, oy + y + dy, OUTLINE);
      }
    }
    rows.forEach(
      (row, y) => [...row].forEach((ch, x) => {
        if (ch === ".") return;
        px(ctx, ox + (flip ? w - 1 - x : x), oy + y, palette[ch] ?? ch);
      })
    );
  }
  function drawHat(ctx, hat, ox, oy, flip) {
    const item = itemById(hat);
    if (!item?.colors) return;
    const [a, b] = item.colors;
    const maps = {
      acorn: ["..bbbb..", ".aaaaaa.", "aaaaaaaa", ".aaaaaa."],
      beanie: ["...bb...", "..aaaa..", ".aaaaaa.", "bbbbbbbb"],
      party: ["...b....", "...a....", "..aba...", ".aaaab..", "abaaaaab"],
      crown: ["a..a..a.", "ab.a.ba.", "aaaaaaaa", "abababa."]
    };
    const rows = maps[hat];
    if (!rows) return;
    const pal = { a, b };
    const x = flip ? ox + 16 - 13 : ox + 5;
    drawMap(ctx, rows, x, oy - rows.length + 2, pal, flip);
  }
  function drawWheel(ctx, wheel, frame) {
    const colors = wheel && itemById(wheel)?.colors || DEFAULT_WHEEL_COLORS;
    const cx = 14;
    const cy = 12.5;
    const r = 12;
    ctx.fillStyle = colors[1];
    for (let a = 0; a < 360; a += 4) {
      const rad = a * Math.PI / 180;
      ctx.fillRect(Math.round(cx + Math.cos(rad) * r - 0.5), Math.round(cy + Math.sin(rad) * r - 0.5), 1, 1);
    }
    ctx.fillStyle = colors[0];
    for (let a = 0; a < 360; a += 3) {
      const rad = a * Math.PI / 180;
      ctx.fillRect(Math.round(cx + Math.cos(rad) * (r - 1) - 0.5), Math.round(cy + Math.sin(rad) * (r - 1) - 0.5), 1, 1);
    }
    for (let i = 0; i < 8; i++) {
      const rad = (i * 45 + frame * 11) * Math.PI / 180;
      ctx.fillRect(Math.round(cx + Math.cos(rad) * (r - 2.5) - 0.5), Math.round(cy + Math.sin(rad) * (r - 2.5) - 0.5), 1, 1);
    }
    ctx.fillStyle = colors[0];
    ctx.fillRect(cx - 1, cy, 2, 1);
    ctx.fillRect(cx - 5, SPRITE_H - 1, 10, 1);
  }
  function drawPal(ctx, d) {
    ctx.imageSmoothingEnabled = false;
    const flip = !!d.flip;
    if (d.pose === "run") drawWheel(ctx, d.wheel, d.frame);
    const bob = d.pose === "run" ? d.frame % 2 : d.pose === "walk" ? d.frame % 2 : 0;
    const ox = d.pose === "run" ? 6 : d.x ?? 6;
    const oy = d.pose === "run" ? 8 + bob : 12 + bob * 0;
    let body = BODY.slice();
    if (d.pose === "nap") {
      body = body.map((r, i) => i === 4 ? r.replace("kw", "oo") : i === 5 ? r.replace("kk", "Ok") : r);
    }
    if (d.mood === "grumpy" && d.pose !== "nap") {
      body = body.map((r, i) => i === 3 ? r.slice(0, 11) + "kk" + r.slice(13) : r);
    }
    const feet = d.pose === "nap" || d.pose === "sit" || d.pose === "eat" ? FEET_SIT : d.frame % 2 ? FEET_B : FEET_A;
    drawMap(ctx, [...body, ...feet], ox, oy, PAL, flip);
    if (d.hat) drawHat(ctx, d.hat, ox, oy, flip);
    if (d.pose === "eat") {
      const sx = flip ? ox - 2 : ox + 16;
      const seed = d.frame % 2 ? [".s", "ss", "s."] : ["s.", "ss", ".s"];
      drawMap(ctx, seed, sx, oy + 5, { s: "#3a3a3a" });
    }
    if (d.pose === "nap") {
      const zx = flip ? ox - 3 : ox + 16;
      const zy = oy - 4 - d.frame % 3;
      drawMap(ctx, ["zzz", "..z", ".z.", "zzz"], zx, zy, { z: "#6b7cff" });
    }
    if (d.mood === "happy" && d.pose === "sit" && d.frame % 4 === 0) {
      drawMap(ctx, [".h.h.", "hhhhh", ".hhh.", "..h.."], flip ? ox - 4 : ox + 15, oy - 6, { h: "#e0457b" });
    }
  }
  var CHEST_ROWS = ["..bbbbbb..", ".baaaaaab.", "bbbbbbbbbb", "baaallaaab", "baaallaaab", "baaaaaaaab", "bbbbbbbbbb"];
  function drawChest(ctx, kind, ox = 1, oy = 1) {
    ctx.imageSmoothingEnabled = false;
    const pal = kind === "golden" ? { a: "#f2c230", b: "#b8860b", l: "#fff6c2" } : kind === "bonus" ? { a: "#7f8cff", b: "#3d47a8", l: "#f2c230" } : { a: "#b7743a", b: "#6b3f1d", l: "#f2c230" };
    drawMap(ctx, CHEST_ROWS, ox, oy, pal);
  }

  // shared/i18n.ts
  var en = {
    "stat.hunger": "Hunger",
    "stat.happiness": "Happiness",
    "stat.energy": "Energy",
    "stat.cleanliness": "Cleanliness",
    "stage.pup": "Pup",
    "stage.junior": "Junior",
    "stage.adult": "Adult",
    "stage.legend": "Wheel Legend",
    "mood.happy": "Happy",
    "mood.ok": "Content",
    "mood.grumpy": "Grumpy",
    "act.feed": "Feed",
    "act.play": "Play",
    "act.clean": "Clean",
    "act.minimize": "Minimise",
    "act.hidePage": "Hide on this page",
    "act.close": "Close",
    "act.open": "Open {name}'s panel",
    "act.restore": "Show {name}",
    "act.openChest": "Open chest",
    "act.openGolden": "Open golden chest",
    "act.buy": "Buy",
    "act.equip": "Wear",
    "act.unequip": "Take off",
    "act.share": "Share my Squeek Pal",
    "act.card": "Download pet card",
    "act.export": "Copy save code",
    "act.import": "Load save code",
    "act.rename": "Rename",
    "label.seeds": "Seeds",
    "label.xp": "XP",
    "label.owned": "Owned",
    "label.wearing": "Wearing",
    "label.price": "{n} Seeds",
    "label.have": "You have {n}",
    "label.nextStage": "{n} XP to next stage",
    "label.maxStage": "Top stage reached",
    "label.questReset": "New quests at 12:00 UTC",
    "label.saveCode": "Save code",
    "label.name": "Pal name",
    "label.lang": "Language",
    "label.inventory": "Food",
    "label.noWheel": "Plain wheel",
    "label.noHat": "No hat",
    "label.waiting": "{n} waiting",
    "tab.pet": "Pet",
    "tab.shop": "Shop",
    "tab.wardrobe": "Wardrobe",
    "tab.quests": "Quests",
    "tab.settings": "Settings",
    "kind.food": "Food",
    "kind.toy": "Toys",
    "kind.hat": "Hats",
    "kind.wheel": "Wheel skins",
    "set.palOn": "Show the pal on x.com",
    "set.chestsOn": "Place seed chests on posts",
    "set.hidden": "Hidden on {n} pages",
    "set.unhide": "Show on all pages again",
    "set.importOk": "Save loaded.",
    "set.importBad": "That code did not load. Paste the whole code, starting with SQK2.",
    "set.copied": "Code copied.",
    "live.title": "Squeektoshi live",
    "live.running": "Running now. Your pal runs too: 1 Seed per wheel turn, chests worth 2x.",
    "live.idle": "Squeektoshi is resting. Your pal naps and recovers energy 2x faster.",
    "live.unknown": "Wheel status unknown right now.",
    "live.offline": "Can't reach the wheel right now",
    "live.waiting": "Checking the wheel",
    "live.speed": "Speed",
    "live.distance": "Distance",
    "live.block": "Block",
    "live.festival": "Golden chest festival until {t}",
    "live.earned": "{n}/300 Seeds from running this hour",
    "live.gentle": "Squeektoshi runs when it wants to. Nothing here asks it to.",
    "chest.got": "+{n} Seeds",
    "chest.item": "and a {item}",
    "chest.normal": "Seed chest",
    "chest.golden": "Golden chest",
    "chest.bonus": "Block bonus chest",
    "err.noSeeds": "Not enough Seeds yet.",
    "err.owned": "Already yours.",
    "quest.open5": "Open 5 chests",
    "quest.golden1": "Find a golden chest",
    "quest.runOnline": "Be online during a run",
    "quest.feed2": "Feed your pal twice",
    "quest.reward": "+20 Seeds, +15 XP",
    "quest.done": "Done",
    "ach.title": "Achievements",
    "ach.count": "{n} of {m} unlocked",
    "log.chest": "Opened a chest: +{n} Seeds",
    "log.golden": "Opened a golden chest: +{n} Seeds",
    "log.run": "Ran with Squeektoshi: +{n} Seeds",
    "log.block": "New Squeek block: a bonus chest is on its way",
    "log.festival": "A wheel record started a golden chest festival",
    "share.text": "Meet {name}, my {stage} Squeek Pal. It runs with Squeektoshi, the real hamster powering Squeekchain.",
    "card.tagline": "Runs with Squeektoshi on Squeekchain",
    "privacy": "Chests only read visible post text, on your device. Nothing is posted, liked or sent anywhere.",
    "item.sunflower": "Sunflower seed",
    "item.carrot": "Carrot slice",
    "item.yogurt": "Yogurt drop",
    "item.chew": "Chew stick",
    "item.ball": "Grass ball",
    "item.tunnel": "Tunnel",
    "item.acorn": "Acorn cap",
    "item.beanie": "Blue beanie",
    "item.party": "Party hat",
    "item.crown": "Tiny crown",
    "item.mint": "Mint wheel",
    "item.sunset": "Sunset wheel",
    "item.golden": "Golden wheel",
    "ach.firstChest": "First chest",
    "ach.chests10": "10 chests",
    "ach.chests50": "50 chests",
    "ach.chests100": "100 chests",
    "ach.firstGolden": "Golden find",
    "ach.golden5": "5 golden chests",
    "ach.firstFeed": "First meal",
    "ach.feeds25": "25 meals",
    "ach.plays25": "25 play times",
    "ach.cleans10": "10 baths",
    "ach.junior": "Grew to Junior",
    "ach.adult": "Grew to Adult",
    "ach.legend": "Wheel Legend",
    "ach.firstRunSeed": "Ran with Squeektoshi",
    "ach.runSeeds500": "500 Seeds from running",
    "ach.firstBuy": "First purchase",
    "ach.allHats": "Every hat",
    "ach.firstQuest": "First quest",
    "ach.quests10": "10 quests",
    "ach.festivalChest": "Festival chest",
    "ach.bonusChest": "Block bonus chest",
    "ach.firstShare": "Shared your pal"
  };
  var vi = {
    "stat.hunger": "No b\u1EE5ng",
    "stat.happiness": "Vui v\u1EBB",
    "stat.energy": "N\u0103ng l\u01B0\u1EE3ng",
    "stat.cleanliness": "S\u1EA1ch s\u1EBD",
    "stage.pup": "B\xE9 con",
    "stage.junior": "Thi\u1EBFu ni\xEAn",
    "stage.adult": "Tr\u01B0\u1EDFng th\xE0nh",
    "stage.legend": "Huy\u1EC1n tho\u1EA1i b\xE1nh xe",
    "mood.happy": "Vui",
    "mood.ok": "B\xECnh th\u01B0\u1EDDng",
    "mood.grumpy": "C\xE1u k\u1EC9nh",
    "act.feed": "Cho \u0103n",
    "act.play": "Ch\u01A1i",
    "act.clean": "T\u1EAFm",
    "act.minimize": "Thu nh\u1ECF",
    "act.hidePage": "\u1EA8n tr\xEAn trang n\xE0y",
    "act.close": "\u0110\xF3ng",
    "act.open": "M\u1EDF b\u1EA3ng c\u1EE7a {name}",
    "act.restore": "Hi\u1EC7n {name}",
    "act.openChest": "M\u1EDF r\u01B0\u01A1ng",
    "act.openGolden": "M\u1EDF r\u01B0\u01A1ng v\xE0ng",
    "act.buy": "Mua",
    "act.equip": "M\u1EB7c",
    "act.unequip": "C\u1EDFi ra",
    "act.share": "Chia s\u1EBB Squeek Pal c\u1EE7a t\xF4i",
    "act.card": "T\u1EA3i th\u1EBB th\xFA c\u01B0ng",
    "act.export": "Sao ch\xE9p m\xE3 l\u01B0u",
    "act.import": "N\u1EA1p m\xE3 l\u01B0u",
    "act.rename": "\u0110\u1ED5i t\xEAn",
    "label.seeds": "H\u1EA1t",
    "label.xp": "XP",
    "label.owned": "\u0110\xE3 c\xF3",
    "label.wearing": "\u0110ang m\u1EB7c",
    "label.price": "{n} H\u1EA1t",
    "label.have": "B\u1EA1n c\xF3 {n}",
    "label.nextStage": "C\xF2n {n} XP \u0111\u1EC3 l\xEAn c\u1EA5p",
    "label.maxStage": "\u0110\xE3 \u0111\u1EA1t c\u1EA5p cao nh\u1EA5t",
    "label.questReset": "Nhi\u1EC7m v\u1EE5 m\u1EDBi l\xFAc 12:00 UTC",
    "label.saveCode": "M\xE3 l\u01B0u",
    "label.name": "T\xEAn th\xFA c\u01B0ng",
    "label.lang": "Ng\xF4n ng\u1EEF",
    "label.inventory": "\u0110\u1ED3 \u0103n",
    "label.noWheel": "B\xE1nh xe th\u01B0\u1EDDng",
    "label.noHat": "Kh\xF4ng \u0111\u1ED9i m\u0169",
    "label.waiting": "{n} \u0111ang ch\u1EDD",
    "tab.pet": "Th\xFA c\u01B0ng",
    "tab.shop": "C\u1EEDa h\xE0ng",
    "tab.wardrobe": "T\u1EE7 \u0111\u1ED3",
    "tab.quests": "Nhi\u1EC7m v\u1EE5",
    "tab.settings": "C\xE0i \u0111\u1EB7t",
    "kind.food": "\u0110\u1ED3 \u0103n",
    "kind.toy": "\u0110\u1ED3 ch\u01A1i",
    "kind.hat": "M\u0169",
    "kind.wheel": "M\xE0u b\xE1nh xe",
    "set.palOn": "Hi\u1EC7n th\xFA c\u01B0ng tr\xEAn x.com",
    "set.chestsOn": "\u0110\u1EB7t r\u01B0\u01A1ng h\u1EA1t tr\xEAn b\xE0i \u0111\u0103ng",
    "set.hidden": "\u0110ang \u1EA9n tr\xEAn {n} trang",
    "set.unhide": "Hi\u1EC7n l\u1EA1i tr\xEAn m\u1ECDi trang",
    "set.importOk": "\u0110\xE3 n\u1EA1p b\u1EA3n l\u01B0u.",
    "set.importBad": "M\xE3 kh\xF4ng h\u1EE3p l\u1EC7. H\xE3y d\xE1n to\xE0n b\u1ED9 m\xE3, b\u1EAFt \u0111\u1EA7u b\u1EB1ng SQK2.",
    "set.copied": "\u0110\xE3 sao ch\xE9p m\xE3.",
    "live.title": "Squeektoshi tr\u1EF1c ti\u1EBFp",
    "live.running": "\u0110ang ch\u1EA1y. Th\xFA c\u01B0ng c\u1EE7a b\u1EA1n c\u0169ng ch\u1EA1y: 1 H\u1EA1t m\u1ED7i v\xF2ng, r\u01B0\u01A1ng gi\xE1 tr\u1ECB g\u1EA5p \u0111\xF4i.",
    "live.idle": "Squeektoshi \u0111ang ngh\u1EC9. Th\xFA c\u01B0ng ng\u1EE7 v\xE0 h\u1ED3i n\u0103ng l\u01B0\u1EE3ng nhanh g\u1EA5p \u0111\xF4i.",
    "live.unknown": "Ch\u01B0a r\xF5 tr\u1EA1ng th\xE1i b\xE1nh xe.",
    "live.offline": "Hi\u1EC7n kh\xF4ng k\u1EBFt n\u1ED1i \u0111\u01B0\u1EE3c b\xE1nh xe",
    "live.waiting": "\u0110ang ki\u1EC3m tra b\xE1nh xe",
    "live.speed": "T\u1ED1c \u0111\u1ED9",
    "live.distance": "Qu\xE3ng \u0111\u01B0\u1EDDng",
    "live.block": "Kh\u1ED1i",
    "live.festival": "L\u1EC5 h\u1ED9i r\u01B0\u01A1ng v\xE0ng \u0111\u1EBFn {t}",
    "live.earned": "{n}/300 H\u1EA1t t\u1EEB vi\u1EC7c ch\u1EA1y trong gi\u1EDD n\xE0y",
    "live.gentle": "Squeektoshi ch\u1EA1y khi n\xF3 mu\u1ED1n. Kh\xF4ng c\xF3 g\xEC \u1EDF \u0111\xE2y th\xFAc \xE9p n\xF3.",
    "chest.got": "+{n} H\u1EA1t",
    "chest.item": "v\xE0 m\u1ED9t {item}",
    "chest.normal": "R\u01B0\u01A1ng h\u1EA1t",
    "chest.golden": "R\u01B0\u01A1ng v\xE0ng",
    "chest.bonus": "R\u01B0\u01A1ng th\u01B0\u1EDFng kh\u1ED1i",
    "err.noSeeds": "Ch\u01B0a \u0111\u1EE7 H\u1EA1t.",
    "err.owned": "B\u1EA1n \u0111\xE3 c\xF3 r\u1ED3i.",
    "quest.open5": "M\u1EDF 5 r\u01B0\u01A1ng",
    "quest.golden1": "T\xECm m\u1ED9t r\u01B0\u01A1ng v\xE0ng",
    "quest.runOnline": "Tr\u1EF1c tuy\u1EBFn khi b\xE1nh xe ch\u1EA1y",
    "quest.feed2": "Cho th\xFA c\u01B0ng \u0103n hai l\u1EA7n",
    "quest.reward": "+20 H\u1EA1t, +15 XP",
    "quest.done": "Xong",
    "ach.title": "Th\xE0nh t\xEDch",
    "ach.count": "M\u1EDF kh\xF3a {n}/{m}",
    "log.chest": "M\u1EDF r\u01B0\u01A1ng: +{n} H\u1EA1t",
    "log.golden": "M\u1EDF r\u01B0\u01A1ng v\xE0ng: +{n} H\u1EA1t",
    "log.run": "Ch\u1EA1y c\xF9ng Squeektoshi: +{n} H\u1EA1t",
    "log.block": "Kh\u1ED1i Squeek m\u1EDBi: s\u1EAFp c\xF3 r\u01B0\u01A1ng th\u01B0\u1EDFng",
    "log.festival": "K\u1EF7 l\u1EE5c b\xE1nh xe m\u1EDF l\u1EC5 h\u1ED9i r\u01B0\u01A1ng v\xE0ng",
    "share.text": "\u0110\xE2y l\xE0 {name}, Squeek Pal c\u1EA5p {stage} c\u1EE7a t\xF4i. N\xF3 ch\u1EA1y c\xF9ng Squeektoshi, ch\xFA hamster th\u1EADt v\u1EADn h\xE0nh Squeekchain.",
    "card.tagline": "Ch\u1EA1y c\xF9ng Squeektoshi tr\xEAn Squeekchain",
    "privacy": "R\u01B0\u01A1ng ch\u1EC9 \u0111\u1ECDc ch\u1EEF hi\u1EC3n th\u1ECB c\u1EE7a b\xE0i \u0111\u0103ng, ngay tr\xEAn m\xE1y b\u1EA1n. Kh\xF4ng \u0111\u0103ng, kh\xF4ng th\xEDch, kh\xF4ng g\u1EEDi g\xEC \u0111i.",
    "item.sunflower": "H\u1EA1t h\u01B0\u1EDBng d\u01B0\u01A1ng",
    "item.carrot": "L\xE1t c\xE0 r\u1ED1t",
    "item.yogurt": "Gi\u1ECDt s\u1EEFa chua",
    "item.chew": "Que g\u1EB7m",
    "item.ball": "B\xF3ng c\u1ECF",
    "item.tunnel": "\u0110\u01B0\u1EDDng h\u1EA7m",
    "item.acorn": "M\u0169 h\u1EA1t d\u1EBB",
    "item.beanie": "M\u0169 len xanh",
    "item.party": "M\u0169 ti\u1EC7c",
    "item.crown": "V\u01B0\u01A1ng mi\u1EC7n nh\u1ECF",
    "item.mint": "B\xE1nh xe b\u1EA1c h\xE0",
    "item.sunset": "B\xE1nh xe ho\xE0ng h\xF4n",
    "item.golden": "B\xE1nh xe v\xE0ng",
    "ach.firstChest": "R\u01B0\u01A1ng \u0111\u1EA7u ti\xEAn",
    "ach.chests10": "10 r\u01B0\u01A1ng",
    "ach.chests50": "50 r\u01B0\u01A1ng",
    "ach.chests100": "100 r\u01B0\u01A1ng",
    "ach.firstGolden": "T\xECm th\u1EA5y v\xE0ng",
    "ach.golden5": "5 r\u01B0\u01A1ng v\xE0ng",
    "ach.firstFeed": "B\u1EEFa \u0103n \u0111\u1EA7u ti\xEAn",
    "ach.feeds25": "25 b\u1EEFa \u0103n",
    "ach.plays25": "25 l\u1EA7n ch\u01A1i",
    "ach.cleans10": "10 l\u1EA7n t\u1EAFm",
    "ach.junior": "L\xEAn Thi\u1EBFu ni\xEAn",
    "ach.adult": "L\xEAn Tr\u01B0\u1EDFng th\xE0nh",
    "ach.legend": "Huy\u1EC1n tho\u1EA1i b\xE1nh xe",
    "ach.firstRunSeed": "Ch\u1EA1y c\xF9ng Squeektoshi",
    "ach.runSeeds500": "500 H\u1EA1t t\u1EEB vi\u1EC7c ch\u1EA1y",
    "ach.firstBuy": "L\u1EA7n mua \u0111\u1EA7u ti\xEAn",
    "ach.allHats": "\u0110\u1EE7 m\u1ECDi m\u0169",
    "ach.firstQuest": "Nhi\u1EC7m v\u1EE5 \u0111\u1EA7u ti\xEAn",
    "ach.quests10": "10 nhi\u1EC7m v\u1EE5",
    "ach.festivalChest": "R\u01B0\u01A1ng l\u1EC5 h\u1ED9i",
    "ach.bonusChest": "R\u01B0\u01A1ng th\u01B0\u1EDFng kh\u1ED1i",
    "ach.firstShare": "\u0110\xE3 chia s\u1EBB th\xFA c\u01B0ng"
  };
  var tables = { en, vi };
  function t(lang, key, vars = {}) {
    const s = tables[lang]?.[key] ?? en[key] ?? key;
    return s.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? ""));
  }
  function fmtNum(lang, n, digits = 0) {
    return n.toLocaleString(lang === "vi" ? "vi-VN" : "en-US", { maximumFractionDigits: digits });
  }

  // shared/rules.ts
  var HOUR = 36e5;
  var MINUTE = 6e4;
  var MAX_DRIFT_MS = 12 * HOUR;
  function mood(stats) {
    const avg = (stats.hunger + stats.happiness + stats.energy + stats.cleanliness) / 4;
    const low = Math.min(stats.hunger, stats.happiness, stats.energy, stats.cleanliness);
    if (avg < 35 || low < 15) return "grumpy";
    if (avg >= 70) return "happy";
    return "ok";
  }
  function isOnline(snap) {
    return (snap.freshness ?? "").toLowerCase() === "online";
  }
  function wheelMode(snap, now) {
    if (snap.reach !== "ok" || now - snap.fetchedAt > 5 * MINUTE) return "unknown";
    if (snap.coreStatus === "ACTIVE" && isOnline(snap)) return "running";
    if (snap.coreStatus === "IDLE") return "idle";
    return "unknown";
  }
  var MENTION = /(^|[^a-z0-9_])(@squeekchain|#squeekchain|squeekchain|\$sqk)(?![a-z0-9_])/i;
  function mentionsSqueekchain(text) {
    return MENTION.test(text);
  }
  function squeekDay(now) {
    return Math.floor((now - 12 * HOUR) / (24 * HOUR));
  }
  var QUEST_GOALS = { open5: 5, golden1: 1, runOnline: 1, feed2: 2 };
  var QUEST_ORDER = ["open5", "golden1", "runOnline", "feed2"];
  function questsForDay(day) {
    const rest = (day % 4 + 4) % 4;
    return QUEST_ORDER.filter((_, i) => i !== rest).map((id) => ({ id, progress: 0, goal: QUEST_GOALS[id], done: false }));
  }

  // shared/selectors.ts
  var SELECTORS = {
    tweet: ['article[data-testid="tweet"]', 'article[role="article"]', '[role="article"]'],
    tweetText: ['[data-testid="tweetText"]', "div[lang]"],
    actionRow: ['div[role="group"]']
  };
  function findTweets(root) {
    for (const sel of SELECTORS.tweet) {
      try {
        const found = Array.from(root.querySelectorAll(sel));
        if (found.length) return found;
      } catch {
      }
    }
    return [];
  }
  function first(el, list2) {
    for (const sel of list2) {
      try {
        const found = el.querySelector(sel);
        if (found) return found;
      } catch {
      }
    }
    return null;
  }
  function tweetText(tweet) {
    const el = first(tweet, SELECTORS.tweetText);
    return el ? el.innerText ?? el.textContent ?? "" : "";
  }
  function actionRow(tweet) {
    const rows = SELECTORS.actionRow.flatMap((sel) => {
      try {
        return Array.from(tweet.querySelectorAll(sel));
      } catch {
        return [];
      }
    });
    return rows.length ? rows[rows.length - 1] : null;
  }

  // shared/chests.ts
  var CHEST_CSS = `
:host { display: inline-flex; align-items: center; margin-inline-start: 4px; }
button { all: unset; box-sizing: border-box; display: inline-grid; place-items: center; width: 34px; height: 34px; border-radius: 999px; cursor: pointer; }
button:hover { background: rgb(242 194 48 / 0.18); }
button:focus-visible { outline: 2px solid #1d9bf0; outline-offset: 1px; }
canvas { width: 24px; height: 18px; image-rendering: pixelated; }
@media (prefers-reduced-motion: no-preference) {
  button { animation: pop 300ms cubic-bezier(0.2, 0, 0, 1); }
  @keyframes pop { from { scale: 0.25; opacity: 0; } to { scale: 1; opacity: 1; } }
}`;
  function chestButton(doc, chest, label, onClick) {
    const host = doc.createElement("span");
    host.setAttribute("data-squeekpal-chest", chest.id);
    const shadow = host.attachShadow({ mode: "open" });
    const style = doc.createElement("style");
    style.textContent = CHEST_CSS;
    const btn = doc.createElement("button");
    btn.type = "button";
    btn.setAttribute("aria-label", label);
    btn.title = label;
    const c = doc.createElement("canvas");
    c.width = 12;
    c.height = 9;
    drawChest(c.getContext("2d"), chest.kind, 1, 1);
    btn.append(c);
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    });
    shadow.append(style, btn);
    return host;
  }
  function startChestPlacer(opts) {
    const seen = /* @__PURE__ */ new WeakSet();
    const doc = opts.root.ownerDocument ?? opts.root;
    let stopped = false;
    const place = (tweet, chest) => {
      const row = actionRow(tweet);
      if (!row) return;
      const lang = opts.store.get()?.settings.lang ?? "en";
      const label = t(lang, chest.kind === "golden" ? "act.openGolden" : "act.openChest");
      const btn = chestButton(doc, chest, label, async () => {
        btn.remove();
        const fx = await opts.store.dispatch({ type: "openChest", id: chest.id });
        opts.onOpened(fx);
      });
      row.append(btn);
    };
    const io = new IntersectionObserver(
      (entries) => {
        for (const en2 of entries) {
          if (!en2.isIntersecting || seen.has(en2.target)) continue;
          seen.add(en2.target);
          io.unobserve(en2.target);
          const tweet = en2.target;
          let mention = false;
          try {
            mention = mentionsSqueekchain(tweetText(tweet));
          } catch {
            mention = false;
          }
          opts.store.dispatch({ type: "tweetSeen", mention }).then((fx) => {
            if (!stopped && fx.chest) place(tweet, fx.chest);
          }).catch(() => {
          });
        }
      },
      { root: opts.scrollRoot ?? null, threshold: 0.6 }
    );
    const scan = () => {
      try {
        for (const tw of findTweets(opts.root)) if (!seen.has(tw)) io.observe(tw);
      } catch {
      }
    };
    let pending = 0;
    const mo = new MutationObserver(() => {
      if (pending) return;
      pending = window.setTimeout(() => {
        pending = 0;
        scan();
      }, 400);
    });
    mo.observe(opts.root, { childList: true, subtree: true });
    scan();
    return () => {
      stopped = true;
      io.disconnect();
      mo.disconnect();
      clearTimeout(pending);
    };
  }

  // shared/game.ts
  var ACHIEVEMENTS = [
    "firstChest",
    "chests10",
    "chests50",
    "chests100",
    "firstGolden",
    "golden5",
    "firstFeed",
    "feeds25",
    "plays25",
    "cleans10",
    "junior",
    "adult",
    "legend",
    "firstRunSeed",
    "runSeeds500",
    "firstBuy",
    "allHats",
    "firstQuest",
    "quests10",
    "festivalChest",
    "bonusChest",
    "firstShare"
  ];
  function isRunning(s, now) {
    return wheelMode(s.sync, now) === "running";
  }
  function festivalOn(s, now) {
    return s.festival.until > now;
  }

  // shared/ui.ts
  var THEME_CSS = `
:host, .sp-root {
  --sp-bg: #fffaf2; --sp-surface: #f6ecdc; --sp-fg: #2b1d14; --sp-muted: #6b5544; --sp-line: #e3d3bb;
  --sp-accent: #a8481a; --sp-accent-fg: #ffffff; --sp-good: #2f7d4f; --sp-warn: #9a5b00; --sp-focus: #1d70b8;
  --sp-shadow: 0 1px 2px rgb(43 29 20 / 0.12), 0 6px 20px rgb(43 29 20 / 0.16);
  color-scheme: light;
}
[data-theme="dim"], :host([data-theme="dim"]) {
  --sp-bg: #1e2a36; --sp-surface: #273544; --sp-fg: #f2ece4; --sp-muted: #b9c2cc; --sp-line: #3a4a5b;
  --sp-accent: #f0a35c; --sp-accent-fg: #1a1209; --sp-good: #7fd6a2; --sp-warn: #f5c76b; --sp-focus: #8ec5ff;
  --sp-shadow: 0 1px 2px rgb(0 0 0 / 0.3), 0 6px 20px rgb(0 0 0 / 0.35);
  color-scheme: dark;
}
[data-theme="dark"], :host([data-theme="dark"]) {
  --sp-bg: #111111; --sp-surface: #1c1c1c; --sp-fg: #f2ece4; --sp-muted: #b3aca4; --sp-line: #333333;
  --sp-accent: #f0a35c; --sp-accent-fg: #1a1209; --sp-good: #7fd6a2; --sp-warn: #f5c76b; --sp-focus: #8ec5ff;
  --sp-shadow: 0 1px 2px rgb(0 0 0 / 0.4), 0 6px 20px rgb(0 0 0 / 0.5);
  color-scheme: dark;
}`;
  function detectXTheme(doc) {
    const bg = getComputedStyle(doc.body).backgroundColor.replace(/\s/g, "");
    if (bg === "rgb(0,0,0)") return "dark";
    if (bg === "rgb(21,32,43)") return "dim";
    if (bg === "rgb(255,255,255)") return "light";
    return matchMedia("(prefers-color-scheme: dark)").matches ? "dim" : "light";
  }
  function esc(s) {
    return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  }
  var STATS = ["hunger", "happiness", "energy", "cleanliness"];
  function statBars(lang, s) {
    return `<dl class="sp-stats">${STATS.map((k) => {
      const v = Math.round(s.pet.stats[k]);
      return `<div class="sp-stat"><dt>${t(lang, `stat.${k}`)}</dt><dd><span class="sp-bar" role="meter" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${v}" aria-label="${t(lang, `stat.${k}`)}"><span style="inline-size:${v}%" class="${v < 25 ? "low" : ""}"></span></span><span class="sp-num">${v}</span></dd></div>`;
    }).join("")}</dl>`;
  }
  function bigFmt(lang, v, div, digits) {
    if (v === null || !/^-?\d+(\.\d+)?$/.test(v)) return null;
    return fmtNum(lang, Number(v) / div, digits);
  }
  function liveStrip(lang, s, now) {
    const snap = s.sync;
    const mode = wheelMode(snap, now);
    let headline;
    let cls = "unknown";
    if (snap.reach === "never") headline = t(lang, "live.waiting");
    else if (snap.reach === "error") {
      headline = t(lang, "live.offline");
      cls = "offline";
    } else if (mode === "running") {
      headline = t(lang, "live.running");
      cls = "running";
    } else if (mode === "idle") {
      headline = t(lang, "live.idle");
      cls = "idle";
    } else headline = t(lang, "live.unknown");
    const speed = bigFmt(lang, snap.speedMmPerSecond, 1, 0);
    const dist = bigFmt(lang, snap.distanceMm, 1e3, 1);
    const block = bigFmt(lang, snap.blockHeight, 1, 0);
    const fest = festivalOn(s, now) ? `<p class="sp-fest">${t(lang, "live.festival", { t: new Date(s.festival.until).toLocaleTimeString(lang === "vi" ? "vi-VN" : "en-US", { hour: "2-digit", minute: "2-digit" }) })}</p>` : "";
    const earned = isRunning(s, now) ? `<p class="sp-small">${t(lang, "live.earned", { n: s.earn.earnedThisHour })}</p>` : "";
    return `<section class="sp-live sp-live-${cls}" aria-label="${t(lang, "live.title")}">
    <h2 class="sp-live-title"><span class="sp-dot" aria-hidden="true"></span>${t(lang, "live.title")}</h2>
    <p class="sp-live-head" role="status">${headline}</p>
    <dl class="sp-live-nums">
      <div><dt>${t(lang, "live.speed")}</dt><dd>${speed === null ? "\u2013" : `${speed} mm/s`}</dd></div>
      <div><dt>${t(lang, "live.distance")}</dt><dd>${dist === null ? "\u2013" : `${dist} m`}</dd></div>
      <div><dt>${t(lang, "live.block")}</dt><dd>${block === null ? "\u2013" : `#${block}`}</dd></div>
    </dl>${fest}${earned}
  </section>`;
  }

  // shared/widget.ts
  var SCALE = 3;
  var CSS = `${THEME_CSS}
:host { all: initial; position: fixed; z-index: 2147483000; inset-inline-end: 16px; inset-block-end: 16px; font: 400 14px/1.45 system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans", Arial, sans-serif; color: var(--sp-fg); }
:host([data-contained]) { position: absolute; z-index: 5; }
* { box-sizing: border-box; }
p, h2, dl, dd { margin: 0; }
button { font: inherit; color: inherit; }
:focus-visible { outline: 2px solid var(--sp-focus); outline-offset: 2px; }
.pal { display: block; padding: 0; border: 0; background: transparent; cursor: grab; touch-action: none; }
.pal canvas { display: block; inline-size: ${SPRITE_W * SCALE}px; block-size: ${SPRITE_H * SCALE}px; image-rendering: pixelated; }
.pal:active { cursor: grabbing; }
.bubble { display: none; inline-size: 24px; block-size: 24px; border-radius: 50%; border: 0; padding: 0; background: var(--sp-accent); box-shadow: var(--sp-shadow); cursor: pointer; position: relative; }
.bubble::after { content: ""; position: absolute; inset: -10px; }
.bubble canvas { inline-size: 16px; block-size: 14px; image-rendering: pixelated; display: block; margin: auto; }
:host([data-min]) .pal, :host([data-min]) .panel { display: none; }
:host([data-min]) .bubble { display: grid; place-items: center; }
.panel { position: absolute; inset-block-end: calc(100% + 8px); inset-inline-end: 0; inline-size: min(300px, calc(100vw - 32px)); padding: 12px; border-radius: 16px; background: var(--sp-bg); box-shadow: var(--sp-shadow); display: grid; gap: 12px; max-block-size: min(calc(100vh - 140px), 520px); overflow-y: auto; overscroll-behavior: contain; }
:host([data-contained]) .panel { max-block-size: calc(min(70vh, 640px) - 110px); }
.panel[hidden] { display: none; }
.head { display: flex; justify-content: space-between; align-items: baseline; gap: 8px; }
.name { font-size: 16px; font-weight: 600; }
.small { font-size: 12px; color: var(--sp-muted); }
.row { display: flex; flex-wrap: wrap; gap: 8px; }
.btn { min-block-size: 36px; padding: 6px 12px; border-radius: 10px; border: 1px solid var(--sp-line); background: var(--sp-surface); cursor: pointer; transition: scale 150ms cubic-bezier(0.2, 0, 0, 1); }
.btn:active { scale: 0.96; }
.btn.primary { background: var(--sp-accent); color: var(--sp-accent-fg); border-color: transparent; font-weight: 600; }
.link { min-block-size: 32px; padding: 4px 8px; border: 0; background: transparent; color: var(--sp-muted); text-decoration: underline; cursor: pointer; }
.sp-stats { display: grid; gap: 4px; }
.sp-stat { display: grid; grid-template-columns: 84px 1fr; align-items: center; gap: 8px; font-size: 12px; }
.sp-stat dt { color: var(--sp-muted); }
.sp-stat dd { display: flex; align-items: center; gap: 6px; }
.sp-bar { flex: 1; block-size: 6px; border-radius: 3px; background: var(--sp-line); overflow: hidden; }
.sp-bar > span { display: block; block-size: 100%; background: var(--sp-good); }
.sp-bar > span.low { background: var(--sp-warn); }
.sp-num { inline-size: 3ch; text-align: end; font-variant-numeric: tabular-nums; }
.sp-live { padding: 8px 10px; border-radius: 10px; background: var(--sp-surface); display: grid; gap: 4px; font-size: 12px; }
.sp-live-title { font-size: 12px; font-weight: 600; display: flex; align-items: center; gap: 6px; }
.sp-dot { inline-size: 8px; block-size: 8px; border-radius: 50%; background: var(--sp-muted); }
.sp-live-running .sp-dot { background: var(--sp-good); }
.sp-live-offline .sp-dot { background: var(--sp-warn); }
.sp-live-nums { display: flex; flex-wrap: wrap; gap: 2px 12px; font-variant-numeric: tabular-nums; }
.sp-live-nums dt { color: var(--sp-muted); }
.sp-small { font-size: 12px; color: var(--sp-muted); }
.sp-fest { font-weight: 600; color: var(--sp-warn); }
.toast { position: absolute; inset-block-end: 8px; inset-inline-end: calc(100% + 8px); inline-size: max-content; max-inline-size: min(240px, calc(100vw - 140px)); padding: 6px 10px; border-radius: 10px; background: var(--sp-fg); color: var(--sp-bg); font-size: 12px; white-space: normal; pointer-events: none; opacity: 0; transition: opacity 150ms ease-out; }
.toast.on { opacity: 1; }
.sr { position: absolute; inline-size: 1px; block-size: 1px; overflow: hidden; clip-path: inset(50%); white-space: nowrap; }
`;
  function mountWidget(opts) {
    const doc = opts.container.ownerDocument;
    const host = doc.createElement("div");
    host.setAttribute("data-squeekpal", "");
    if (opts.contained) host.setAttribute("data-contained", "");
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `<style>${CSS}</style>
    <div class="toast" aria-hidden="true"></div>
    <p class="sr" role="status"></p>
    <section class="panel" hidden></section>
    <button class="pal" type="button" aria-expanded="false"><canvas width="${SPRITE_W * SCALE}" height="${SPRITE_H * SCALE}"></canvas></button>
    <button class="bubble" type="button"><canvas width="${16 * 2}" height="${14 * 2}"></canvas></button>`;
    opts.container.append(host);
    const palBtn = shadow.querySelector(".pal");
    const bubble = shadow.querySelector(".bubble");
    const panel = shadow.querySelector(".panel");
    const toastEl = shadow.querySelector(".toast");
    const live = shadow.querySelector(".sr");
    const ctx = palBtn.querySelector("canvas").getContext("2d");
    const bctx = bubble.querySelector("canvas").getContext("2d");
    const reduced = matchMedia("(prefers-reduced-motion: reduce)");
    let frame = 0;
    let walkX = 6;
    let dir = 1;
    let eatUntil = 0;
    let lastState = null;
    const pose = (s, now) => {
      if (now < eatUntil) return "eat";
      const mode = wheelMode(s.sync, now);
      if (mode === "running") return "run";
      if (mode === "idle" || s.pet.stats.energy < 20) return "nap";
      if (reduced.matches) return "sit";
      return Math.floor(frame / 24) % 3 === 2 ? "sit" : "walk";
    };
    const draw = () => {
      const s = store.get();
      if (!s) return;
      const now = Date.now();
      const p = pose(s, now);
      if (p === "walk") {
        walkX += dir * 0.5;
        if (walkX > 11 || walkX < 1) dir = -dir;
      }
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, SPRITE_W * SCALE, SPRITE_H * SCALE);
      ctx.scale(SCALE, SCALE);
      drawPal(ctx, { pose: p, frame, hat: s.pet.hat, wheel: s.pet.wheel, mood: mood(s.pet.stats), flip: dir < 0 && p === "walk", x: Math.round(walkX) });
      bctx.setTransform(1, 0, 0, 1, 0, 0);
      bctx.clearRect(0, 0, 32, 28);
      bctx.scale(2, 2);
      bctx.translate(-6, -12);
      drawPal(bctx, { pose: "sit", frame: 0, hat: null, wheel: null, mood: "ok" });
    };
    const { store } = opts;
    const bounds = () => opts.contained ? opts.container.getBoundingClientRect() : { left: 0, top: 0, right: innerWidth, bottom: innerHeight, width: innerWidth, height: innerHeight };
    const clampPosition = () => {
      const box = bounds();
      const size = host.hasAttribute("data-min") ? { width: 24, height: 24 } : { width: SPRITE_W * SCALE, height: SPRITE_H * SCALE };
      const pos = lastState?.settings.pos;
      host.style.insetInlineEnd = `${Math.max(0, Math.min(pos?.x ?? 16, box.width - size.width))}px`;
      host.style.insetBlockEnd = `${Math.max(0, Math.min(pos?.y ?? 16, box.height - size.height))}px`;
    };
    const positionPanel = () => {
      if (panel.hidden) return;
      const box = bounds(), r = host.getBoundingClientRect();
      panel.style.inlineSize = `${Math.min(300, Math.max(0, box.width - 16))}px`;
      const width = panel.getBoundingClientRect().width;
      const left = Math.max(box.left + 8, Math.min(r.right - width, box.right - width - 8));
      panel.style.insetInlineEnd = "auto";
      panel.style.insetInlineStart = `${left - r.left}px`;
      const above = Math.max(0, r.top - box.top - 8);
      const below = Math.max(0, box.bottom - r.bottom - 8);
      const openBelow = above < panel.scrollHeight && below > above;
      panel.style.maxBlockSize = `${Math.min(520, openBelow ? below : above)}px`;
      panel.style.insetBlockEnd = openBelow ? "auto" : "calc(100% + 8px)";
      panel.style.insetBlockStart = openBelow ? "calc(100% + 8px)" : "auto";
    };
    const applyState = (s) => {
      lastState = s;
      const lang = s.settings.lang;
      const hidden = !s.settings.palOn || s.settings.hiddenPaths.includes(opts.pageKey());
      host.style.display = hidden ? "none" : "";
      host.toggleAttribute("data-min", s.settings.minimized);
      palBtn.setAttribute("aria-label", t(lang, "act.open", { name: s.pet.name }));
      bubble.setAttribute("aria-label", t(lang, "act.restore", { name: s.pet.name }));
      clampPosition();
      if (!panel.hidden) renderPanel();
      draw();
    };
    const renderPanel = () => {
      const s = lastState;
      if (!s) return;
      const lang = s.settings.lang;
      const waiting = s.chests.pending.filter((c) => c.createdAt > 0);
      const focusKey = shadow.activeElement?.dataset.k;
      panel.setAttribute("aria-label", s.pet.name);
      panel.innerHTML = `
      <div class="head"><p class="name">${esc(s.pet.name)}</p><p class="small">${esc(String(s.seeds))} ${t(lang, "label.seeds")}</p></div>
      ${statBars(lang, s)}
      <div class="row">
        <button class="btn primary" data-k="feed" data-act="feed">${t(lang, "act.feed")}</button>
        <button class="btn" data-k="play" data-act="play">${t(lang, "act.play")}</button>
        <button class="btn" data-k="clean" data-act="clean">${t(lang, "act.clean")}</button>
      </div>
      ${waiting.length ? `<button class="btn" data-k="chest" data-act="chest" data-id="${esc(waiting[0].id)}">${t(lang, waiting[0].kind === "golden" ? "act.openGolden" : "act.openChest")} (${t(lang, "label.waiting", { n: waiting.length })})</button>` : ""}
      ${liveStrip(lang, s, Date.now())}
      <div class="row">
        <button class="link" data-k="min" data-act="min">${t(lang, "act.minimize")}</button>
        <button class="link" data-k="hide" data-act="hide">${t(lang, "act.hidePage")}</button>
        <button class="link" data-k="close" data-act="close">${t(lang, "act.close")}</button>
      </div>`;
      if (focusKey) panel.querySelector(`[data-k="${focusKey}"]`)?.focus();
      positionPanel();
    };
    const setOpen = (open, focusPanel = false) => {
      panel.hidden = !open;
      host.toggleAttribute("data-open", open);
      palBtn.setAttribute("aria-expanded", String(open));
      if (open) {
        renderPanel();
        if (focusPanel) panel.querySelector("button")?.focus();
      }
    };
    let toastTimer = 0;
    const showToast = (text) => {
      if (!text) return;
      toastEl.textContent = text;
      live.textContent = text;
      toastEl.classList.add("on");
      clearTimeout(toastTimer);
      toastTimer = window.setTimeout(() => toastEl.classList.remove("on"), 2800);
    };
    const toast = (fx) => {
      const lang = store.get()?.settings.lang ?? "en";
      if (fx.opened) {
        const item = fx.opened.item ? ` ${t(lang, "chest.item", { item: t(lang, `item.${fx.opened.item}`) })}` : "";
        showToast(`${t(lang, `chest.${fx.opened.kind}`)}: ${t(lang, "chest.got", { n: fx.opened.seeds })}${item}`);
      } else if (fx.achievements?.length) {
        showToast(`${t(lang, "ach.title")}: ${fx.achievements.map((a) => t(lang, `ach.${a}`)).join(", ")}`);
      }
    };
    panel.addEventListener("click", async (e) => {
      const el = e.target.closest("[data-act]");
      if (!el) return;
      const act = el.dataset.act;
      if (act === "feed" || act === "play" || act === "clean") {
        if (act === "feed") eatUntil = Date.now() + 2e3;
        toast(await store.dispatch({ type: act }));
      } else if (act === "chest") {
        toast(await store.dispatch({ type: "openChest", id: el.dataset.id }));
      } else if (act === "min") {
        setOpen(false);
        await store.dispatch({ type: "settings", patch: { minimized: true } });
        bubble.focus();
      } else if (act === "hide") {
        setOpen(false);
        await store.dispatch({ type: "hidePath", path: opts.pageKey(), hidden: true });
      } else if (act === "close") {
        setOpen(false);
        palBtn.focus();
      }
    });
    shadow.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && !panel.hidden) {
        setOpen(false);
        palBtn.focus();
      }
    });
    bubble.addEventListener("click", () => {
      void store.dispatch({ type: "settings", patch: { minimized: false } }).then(() => palBtn.focus());
    });
    let drag = null;
    palBtn.addEventListener("pointerdown", (e) => {
      const r = host.getBoundingClientRect();
      const box = bounds();
      drag = { x: e.clientX, y: e.clientY, right: box.right - r.right, bottom: box.bottom - r.bottom, moved: false };
      palBtn.setPointerCapture(e.pointerId);
    });
    palBtn.addEventListener("pointermove", (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.x;
      const dy = e.clientY - drag.y;
      if (!drag.moved && Math.hypot(dx, dy) < 5) return;
      drag.moved = true;
      const box = bounds();
      const x = Math.max(0, Math.min(drag.right - dx, box.width - SPRITE_W * SCALE));
      const y = Math.max(0, Math.min(drag.bottom - dy, box.height - SPRITE_H * SCALE));
      host.style.insetInlineEnd = `${x}px`;
      host.style.insetBlockEnd = `${y}px`;
      positionPanel();
    });
    palBtn.addEventListener("pointerup", () => {
      if (drag?.moved) {
        const x = parseFloat(host.style.insetInlineEnd) || 0;
        const y = parseFloat(host.style.insetBlockEnd) || 0;
        void store.dispatch({ type: "settings", patch: { pos: { x: Math.round(x), y: Math.round(y) } } });
      }
    });
    palBtn.addEventListener("click", (e) => {
      if (drag?.moved) {
        drag = null;
        e.preventDefault();
        return;
      }
      drag = null;
      setOpen(!host.hasAttribute("data-open"), e.detail === 0);
    });
    const unsub = store.subscribe(applyState);
    const s0 = store.get();
    if (s0) applyState(s0);
    const tick = window.setInterval(() => {
      if (doc.hidden) return;
      if (!reduced.matches) frame++;
      draw();
    }, 180);
    const themeTimer = window.setInterval(() => host.setAttribute("data-theme", opts.theme()), 2e3);
    host.setAttribute("data-theme", opts.theme());
    const panelTimer = window.setInterval(() => !panel.hidden && renderPanel(), 3e4);
    const onReduced = () => draw();
    reduced.addEventListener("change", onReduced);
    const onResize = () => {
      clampPosition();
      positionPanel();
    };
    window.addEventListener("resize", onResize);
    const resizeObserver = new ResizeObserver(onResize);
    if (opts.contained) resizeObserver.observe(opts.container);
    return {
      toast,
      destroy() {
        unsub();
        clearInterval(tick);
        clearInterval(themeTimer);
        clearInterval(panelTimer);
        reduced.removeEventListener("change", onReduced);
        window.removeEventListener("resize", onResize);
        resizeObserver.disconnect();
        host.remove();
      }
    };
  }

  // shared/state.ts
  var STORAGE_KEY = "squeekpal";
  function emptySnapshot() {
    return {
      fetchedAt: 0,
      coreStatus: null,
      freshness: null,
      rpmMilli: null,
      speedMmPerSecond: null,
      distanceMm: null,
      cumulativeWorkUnits: null,
      blockHeight: null,
      blockProgress: null,
      reach: "never",
      retryAfter: 0
    };
  }
  function defaultState(now, lang = "en") {
    return {
      version: 2,
      createdAt: now,
      lastTick: now,
      pet: {
        name: "Pip",
        stats: { hunger: 80, happiness: 80, energy: 80, cleanliness: 80 },
        xp: 0,
        hat: null,
        wheel: null
      },
      seeds: 10,
      inventory: { sunflower: 2 },
      owned: [],
      chests: { seenSinceLast: 0, placedTimes: [], pending: [], opened: 0, goldenOpened: 0 },
      earn: { hourStart: now, earnedThisHour: 0, totalRunSeeds: 0 },
      counters: { feeds: 0, plays: 0, cleans: 0, shares: 0, questsDone: 0, seedsTotal: 0 },
      quests: { day: -1, list: [] },
      achievements: [],
      festival: { until: 0, seenIds: [] },
      sync: emptySnapshot(),
      lastXSeen: 0,
      settings: {
        lang,
        chestsOn: true,
        palOn: true,
        minimized: false,
        hiddenPaths: [],
        pos: null
      },
      log: []
    };
  }
  function clampNum(v, lo, hi, fallback) {
    const n = typeof v === "number" && Number.isFinite(v) ? v : fallback;
    return Math.min(hi, Math.max(lo, n));
  }
  function record(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v) ? v : {};
  }
  var list = (v) => Array.isArray(v) ? v : [];
  function sanitizeV2(raw, now) {
    const r = record(raw);
    const s = defaultState(now);
    const time = (v, fallback = 0, hi = now) => clampNum(v, 0, hi, fallback);
    const count = (v, fallback = 0, hi = 1e9) => Math.floor(clampNum(v, 0, hi, fallback));
    const pet = record(r.pet), stats = record(pet.stats);
    s.createdAt = time(r.createdAt, now);
    s.lastTick = time(r.lastTick, now);
    s.lastXSeen = time(r.lastXSeen);
    s.pet.name = typeof pet.name === "string" && pet.name.trim() ? pet.name.trim().slice(0, 16) : s.pet.name;
    for (const k of Object.keys(s.pet.stats)) s.pet.stats[k] = clampNum(stats[k], 0, 100, s.pet.stats[k]);
    s.pet.xp = count(pet.xp);
    for (const slot of ["hat", "wheel"]) {
      const id = pet[slot];
      s.pet[slot] = typeof id === "string" && itemById(id)?.kind === slot ? id : null;
    }
    s.seeds = count(r.seeds, s.seeds);
    if (r.inventory !== void 0 && r.inventory !== null && typeof r.inventory === "object" && !Array.isArray(r.inventory)) {
      const inventory = record(r.inventory);
      s.inventory = Object.fromEntries(ITEMS.filter((i) => i.kind === "food" && Object.hasOwn(inventory, i.id)).map((i) => [i.id, count(inventory[i.id], 0, 1e6)]));
    }
    s.owned = [...new Set(list(r.owned).filter((id) => typeof id === "string" && !!itemById(id) && itemById(id).kind !== "food"))];
    const chests = record(r.chests);
    s.chests.seenSinceLast = count(chests.seenSinceLast);
    s.chests.opened = count(chests.opened);
    s.chests.goldenOpened = count(chests.goldenOpened);
    s.chests.placedTimes = list(chests.placedTimes).filter((v) => typeof v === "number" && Number.isFinite(v) && v >= now - 36e5 && v <= now).slice(-12);
    const chestIds = /* @__PURE__ */ new Set();
    for (const entry of list(chests.pending).slice(-12)) {
      const c = record(entry);
      if (typeof c.id !== "string" || !/^[a-z0-9]{1,64}$/.test(c.id) || chestIds.has(c.id)) continue;
      if (c.kind !== "normal" && c.kind !== "golden" && c.kind !== "bonus") continue;
      if (typeof c.createdAt !== "number" || !Number.isFinite(c.createdAt) || c.createdAt < 0 || c.createdAt > now) continue;
      chestIds.add(c.id);
      s.chests.pending.push({ id: c.id, kind: c.kind, createdAt: c.createdAt });
    }
    const earn = record(r.earn);
    s.earn = { hourStart: time(earn.hourStart, now), earnedThisHour: count(earn.earnedThisHour, 0, 300), totalRunSeeds: count(earn.totalRunSeeds) };
    const counters = record(r.counters);
    for (const k of Object.keys(s.counters)) s.counters[k] = count(counters[k]);
    const quests = record(r.quests);
    if (typeof quests.day === "number" && Number.isInteger(quests.day) && quests.day >= 0 && quests.day <= squeekDay(now)) {
      s.quests.day = quests.day;
      s.quests.list = questsForDay(quests.day).map((q) => {
        const saved = list(quests.list).map(record).find((v) => v.id === q.id);
        const progress = count(saved?.progress, 0, q.goal);
        return { ...q, progress, done: progress >= q.goal };
      });
    }
    s.achievements = ACHIEVEMENTS.filter((id) => list(r.achievements).includes(id));
    const festival = record(r.festival);
    s.festival.until = time(festival.until, 0, now + 36e5);
    s.festival.seenIds = [...new Set(list(festival.seenIds).filter((id) => typeof id === "string" && id.length > 0 && id.length <= 256))].slice(-200);
    const sync = record(r.sync);
    s.sync.fetchedAt = time(sync.fetchedAt);
    s.sync.retryAfter = time(sync.retryAfter, 0, Number.MAX_SAFE_INTEGER);
    s.sync.coreStatus = ["ACTIVE", "IDLE", "COUNTER_FAULT"].includes(sync.coreStatus) ? sync.coreStatus : null;
    s.sync.freshness = typeof sync.freshness === "string" && /^(online|stale|offline|unknown)$/i.test(sync.freshness) ? sync.freshness : null;
    for (const k of ["rpmMilli", "speedMmPerSecond", "distanceMm", "cumulativeWorkUnits", "blockHeight", "blockProgress"]) {
      const v = sync[k];
      s.sync[k] = typeof v === "string" && /^\d+(\.\d+)?$/.test(v) && v.length <= 100 ? v : null;
    }
    s.sync.reach = sync.reach === "ok" || sync.reach === "error" ? sync.reach : "never";
    const settings = record(r.settings);
    s.settings.lang = settings.lang === "vi" ? "vi" : "en";
    for (const k of ["chestsOn", "palOn", "minimized"]) if (typeof settings[k] === "boolean") s.settings[k] = settings[k];
    s.settings.hiddenPaths = [...new Set(list(settings.hiddenPaths).filter((p) => typeof p === "string" && p.startsWith("/") && p.length <= 2048))].slice(-200);
    const pos = record(settings.pos);
    if (typeof pos.x === "number" && Number.isFinite(pos.x) && typeof pos.y === "number" && Number.isFinite(pos.y)) {
      s.settings.pos = { x: count(pos.x, 0, 1e5), y: count(pos.y, 0, 1e5) };
    }
    const logKeys = ["log.chest", "log.golden", "log.run", "log.block", "log.festival"];
    s.log = list(r.log).map(record).filter((l) => typeof l.key === "string" && logKeys.includes(l.key)).slice(0, 12).map((l) => ({ t: time(l.t), key: l.key, ...l.n === void 0 ? {} : { n: count(l.n) } }));
    return s;
  }
  function migrate(raw, now) {
    if (!raw || typeof raw !== "object") return defaultState(now);
    const r = raw;
    if (r.version === 1) {
      const v1 = raw;
      const s = defaultState(now, v1.lang === "vi" ? "vi" : "en");
      s.pet.name = typeof v1.name === "string" && v1.name.trim() ? v1.name.slice(0, 16) : s.pet.name;
      for (const k of Object.keys(s.pet.stats)) {
        s.pet.stats[k] = clampNum(v1.stats?.[k], 0, 100, s.pet.stats[k]);
      }
      s.pet.xp = clampNum(v1.xp, 0, 1e9, 0);
      s.seeds = clampNum(v1.seeds, 0, 1e9, s.seeds);
      if (v1.inventory && typeof v1.inventory === "object") s.inventory = { ...v1.inventory };
      return sanitizeV2(s, now);
    }
    if (r.version === 2) {
      return sanitizeV2(raw, now);
    }
    return defaultState(now);
  }

  // extension/chromeStore.ts
  async function chromeStore() {
    let state = null;
    const subs = /* @__PURE__ */ new Set();
    const got = await chrome.storage.local.get(STORAGE_KEY);
    if (got[STORAGE_KEY]) state = migrate(got[STORAGE_KEY], Date.now());
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes[STORAGE_KEY]?.newValue) return;
      state = migrate(changes[STORAGE_KEY].newValue, Date.now());
      for (const fn of subs) fn(state);
    });
    const store = {
      get: () => state,
      async dispatch(action) {
        try {
          const fx = await chrome.runtime.sendMessage({ type: "squeekpal:dispatch", action });
          const fresh = await chrome.storage.local.get(STORAGE_KEY);
          if (fresh[STORAGE_KEY]) {
            state = migrate(fresh[STORAGE_KEY], Date.now());
            for (const fn of subs) fn(state);
          }
          return fx ?? {};
        } catch {
          return {};
        }
      },
      subscribe(fn) {
        subs.add(fn);
        return () => subs.delete(fn);
      }
    };
    if (!state) await store.dispatch({ type: "tick" });
    return store;
  }

  // extension/content.ts
  var pageKey = () => location.pathname.replace(/\/+$/, "") || "/";
  async function main() {
    if (document.querySelector("[data-squeekpal]")) return;
    const store = await chromeStore();
    const widget = mountWidget({ store, container: document.body, pageKey, theme: () => detectXTheme(document) });
    let stopChests = null;
    const syncChests = () => {
      const on = store.get()?.settings.chestsOn ?? true;
      if (on && !stopChests) {
        try {
          stopChests = startChestPlacer({ store, root: document.body, onOpened: (fx) => widget.toast(fx) });
        } catch {
          stopChests = null;
        }
      } else if (!on && stopChests) {
        stopChests();
        stopChests = null;
        document.querySelectorAll("[data-squeekpal-chest]").forEach((el) => el.remove());
      }
    };
    syncChests();
    store.subscribe(syncChests);
    const beat = () => {
      if (!document.hidden) void store.dispatch({ type: "heartbeat" });
    };
    beat();
    setInterval(beat, 3e4);
    document.addEventListener("visibilitychange", beat);
  }
  void main();
})();
