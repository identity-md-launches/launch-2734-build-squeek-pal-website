"use strict";
(() => {
  // shared/catalog.ts
  var ITEMS = [
    { id: "sunflower", kind: "food", price: 4, power: 15 },
    { id: "carrot", kind: "food", price: 8, power: 25 },
    { id: "yogurt", kind: "food", price: 14, power: 40 },
    { id: "chew", kind: "toy", price: 20, power: 6 },
    { id: "ball", kind: "toy", price: 30, power: 9 },
    { id: "tunnel", kind: "toy", price: 45, power: 12 },
    { id: "acorn", kind: "hat", price: 25, colors: ["#8a5a2b", "#c98b45"] },
    { id: "beanie", kind: "hat", price: 35, colors: ["#3b7dd8", "#f2f2f2"] },
    { id: "party", kind: "hat", price: 50, colors: ["#e0457b", "#ffd447"] },
    { id: "crown", kind: "hat", price: 90, colors: ["#f2b705", "#fff1a8"] },
    { id: "mint", kind: "wheel", price: 30, colors: ["#3fb68b", "#bff0dc"] },
    { id: "sunset", kind: "wheel", price: 45, colors: ["#e8743b", "#ffd0a8"] },
    { id: "golden", kind: "wheel", price: 120, colors: ["#d4a017", "#fff0a0"] }
  ];
  function itemById(id) {
    return ITEMS.find((i) => i.id === id);
  }

  // shared/rules.ts
  var HOUR = 36e5;
  var MINUTE = 6e4;
  var MAX_DRIFT_MS = 12 * HOUR;
  var TWEETS_PER_CHEST = 20;
  var CHESTS_PER_HOUR = 12;
  var RUN_SEEDS_PER_HOUR = 300;
  var FESTIVAL_MS = HOUR;
  var X_TAB_FRESH_MS = 9e4;
  var DRIFT_PER_HOUR = { hunger: -6, happiness: -4, energy: -3, cleanliness: -3 };
  var NAP_ENERGY_PER_HOUR = 6;
  var clamp = (n) => Math.min(100, Math.max(0, n));
  function drift(stats, elapsedMs, opts) {
    const hours = Math.min(Math.max(0, elapsedMs), MAX_DRIFT_MS) / HOUR;
    const energyRate = opts.napping ? NAP_ENERGY_PER_HOUR * (opts.idleBoost ? 2 : 1) : DRIFT_PER_HOUR.energy;
    return {
      hunger: clamp(stats.hunger + DRIFT_PER_HOUR.hunger * hours),
      happiness: clamp(stats.happiness + DRIFT_PER_HOUR.happiness * hours),
      energy: clamp(stats.energy + energyRate * hours),
      cleanliness: clamp(stats.cleanliness + DRIFT_PER_HOUR.cleanliness * hours)
    };
  }
  var STAGES = [
    { id: "pup", xp: 0 },
    { id: "junior", xp: 120 },
    { id: "adult", xp: 450 },
    { id: "legend", xp: 1500 }
  ];
  function stageFor(xp) {
    let s = "pup";
    for (const st of STAGES) if (xp >= st.xp) s = st.id;
    return s;
  }
  function isOnline(snap) {
    return (snap.freshness ?? "").toLowerCase() === "online";
  }
  function wheelMode(snap, now) {
    if (snap.reach !== "ok" || now - snap.fetchedAt > 5 * MINUTE) return "unknown";
    if (snap.coreStatus === "ACTIVE" && isOnline(snap)) return "running";
    if (snap.coreStatus === "IDLE") return "idle";
    return "unknown";
  }
  function big(s) {
    if (s === null || !/^\d+$/.test(s)) return null;
    return BigInt(s);
  }
  function syncEarnings(inp) {
    let { hourStart, earnedThisHour } = inp;
    if (inp.now - hourStart >= HOUR) {
      hourStart = inp.now;
      earnedThisHour = 0;
    }
    const none = { seeds: 0, hourStart, earnedThisHour };
    if (!inp.xTabOpen) return none;
    if (inp.next.coreStatus !== "ACTIVE" || !isOnline(inp.next)) return none;
    const a = big(inp.prev.cumulativeWorkUnits);
    const b = big(inp.next.cumulativeWorkUnits);
    if (a === null || b === null || b <= a) return none;
    const passes = b - a;
    const room = BigInt(Math.max(0, RUN_SEEDS_PER_HOUR - earnedThisHour));
    const seeds = Number(passes < room ? passes : room);
    return { seeds, hourStart, earnedThisHour: earnedThisHour + seeds };
  }
  function newBlock(prev, next) {
    const a = big(prev.blockHeight);
    const b = big(next.blockHeight);
    return a !== null && b !== null && b > a;
  }
  function recentPlacements(times, now) {
    return times.filter((t) => now - t < HOUR);
  }
  function chestAllowed(inp) {
    return inp.seenSinceLast >= TWEETS_PER_CHEST && recentPlacements(inp.placedTimes, inp.now).length < CHESTS_PER_HOUR;
  }
  function bonusAllowed(placedTimes, now) {
    return recentPlacements(placedTimes, now).length < CHESTS_PER_HOUR;
  }
  function chestKindFor(mention, festival, roll) {
    if (festival) return "golden";
    if (mention && roll < 0.5) return "golden";
    return "normal";
  }
  var ITEM_DROPS = ["sunflower", "sunflower", "carrot", "carrot", "yogurt"];
  function chestReward(kind, running, rolls) {
    const [a, b, c] = rolls;
    const base = kind === "golden" ? 15 + Math.floor(a * 16) : kind === "bonus" ? 10 + Math.floor(a * 11) : 3 + Math.floor(a * 6);
    const itemChance = kind === "golden" ? 0.35 : kind === "bonus" ? 0.25 : 0.15;
    const item = b < itemChance ? ITEM_DROPS[Math.floor(c * ITEM_DROPS.length)] : null;
    return { seeds: base * (running ? 2 : 1), item, xp: kind === "golden" ? 10 : kind === "bonus" ? 7 : 4 };
  }
  function isFestivalEvent(type) {
    const t = type.toLowerCase();
    return t === "measurement.speed_record" || t.includes("distance_milestone") || t === "measurement.milestone";
  }
  function applyFestival(inp) {
    const seen = new Set(inp.seenIds);
    let until = inp.until;
    let started = false;
    for (const ev of inp.events) {
      if (seen.has(ev.id)) continue;
      seen.add(ev.id);
      if (!isFestivalEvent(ev.type)) continue;
      if (inp.now - ev.at > HOUR) continue;
      if (ev.at < inp.installedAt - HOUR) continue;
      const end = ev.at + FESTIVAL_MS;
      if (end > until && end > inp.now) {
        until = end;
        started = true;
      }
    }
    return { until, seenIds: [...seen].slice(-200), started };
  }
  function squeekDay(now) {
    return Math.floor((now - 12 * HOUR) / (24 * HOUR));
  }
  var QUEST_GOALS = { open5: 5, golden1: 1, runOnline: 1, feed2: 2 };
  var QUEST_ORDER = ["open5", "golden1", "runOnline", "feed2"];
  function questsForDay(day) {
    const rest = (day % 4 + 4) % 4;
    return QUEST_ORDER.filter((_, i) => i !== rest).map((id) => ({ id, progress: 0, goal: QUEST_GOALS[id], done: false }));
  }
  var QUEST_REWARD = { seeds: 20, xp: 15 };
  function progressQuest(list2, id, by = 1) {
    const completed = [];
    const next = list2.map((q) => {
      if (q.id !== id || q.done) return q;
      const progress = Math.min(q.goal, q.progress + by);
      const done = progress >= q.goal;
      if (done) completed.push(q.id);
      return { ...q, progress, done };
    });
    return { list: next, completed };
  }

  // shared/game.ts
  var ACHIEVEMENTS = [
    "firstChest",
    "chests10",
    "chests50",
    "chests100",
    "firstGolden",
    "golden5",
    "firstFeed",
    "feeds25",
    "plays25",
    "cleans10",
    "junior",
    "adult",
    "legend",
    "firstRunSeed",
    "runSeeds500",
    "firstBuy",
    "allHats",
    "firstQuest",
    "quests10",
    "festivalChest",
    "bonusChest",
    "firstShare"
  ];
  function clone(s) {
    return structuredClone(s);
  }
  function logLine(s, now, key, n) {
    s.log = [{ t: now, key, n }, ...s.log].slice(0, 12);
  }
  function addXp(s, xp) {
    s.pet.xp += xp;
  }
  function addSeeds(s, n) {
    s.seeds += n;
    s.counters.seedsTotal += n;
  }
  function quest(s, id, fx, by = 1) {
    const r = progressQuest(s.quests.list, id, by);
    s.quests.list = r.list;
    for (const q of r.completed) {
      addSeeds(s, QUEST_REWARD.seeds);
      addXp(s, QUEST_REWARD.xp);
      s.counters.questsDone += 1;
      fx.quests = [...fx.quests ?? [], q];
    }
  }
  function checkAchievements(s, fx, extra = []) {
    const stage = stageFor(s.pet.xp);
    const hats = ITEMS.filter((i) => i.kind === "hat").map((i) => i.id);
    const tests = {
      firstChest: s.chests.opened >= 1,
      chests10: s.chests.opened >= 10,
      chests50: s.chests.opened >= 50,
      chests100: s.chests.opened >= 100,
      firstGolden: s.chests.goldenOpened >= 1,
      golden5: s.chests.goldenOpened >= 5,
      firstFeed: s.counters.feeds >= 1,
      feeds25: s.counters.feeds >= 25,
      plays25: s.counters.plays >= 25,
      cleans10: s.counters.cleans >= 10,
      junior: stage !== "pup",
      adult: stage === "adult" || stage === "legend",
      legend: stage === "legend",
      firstRunSeed: s.earn.totalRunSeeds >= 1,
      runSeeds500: s.earn.totalRunSeeds >= 500,
      firstBuy: s.owned.length > 0 || s.counters.seedsTotal < 0,
      allHats: hats.every((h) => s.owned.includes(h)),
      firstQuest: s.counters.questsDone >= 1,
      quests10: s.counters.questsDone >= 10,
      firstShare: s.counters.shares >= 1
    };
    for (const e of extra) tests[e] = true;
    for (const id of ACHIEVEMENTS) {
      if (tests[id] && !s.achievements.includes(id)) {
        s.achievements.push(id);
        fx.achievements = [...fx.achievements ?? [], id];
      }
    }
  }
  function advance(s, now) {
    const mode = wheelMode(s.sync, now);
    const napping = mode === "idle" || s.pet.stats.energy < 20;
    s.pet.stats = drift(s.pet.stats, now - s.lastTick, { napping, idleBoost: mode === "idle" });
    s.lastTick = Math.max(s.lastTick, now);
    const day = squeekDay(now);
    if (s.quests.day !== day) s.quests = { day, list: questsForDay(day) };
    s.chests.placedTimes = recentPlacements(s.chests.placedTimes, now);
  }
  function isRunning(s, now) {
    return wheelMode(s.sync, now) === "running";
  }
  function festivalOn(s, now) {
    return s.festival.until > now;
  }
  function reduce(prev, action, ctx) {
    const s = clone(prev);
    const fx = {};
    const { now, rand } = ctx;
    advance(s, now);
    const st = s.pet.stats;
    const up = (k, n) => st[k] = Math.min(100, Math.max(0, st[k] + n));
    switch (action.type) {
      case "tick":
        break;
      case "heartbeat":
        s.lastXSeen = now;
        break;
      case "tweetSeen": {
        s.lastXSeen = now;
        s.chests.seenSinceLast += 1;
        if (!s.settings.chestsOn) break;
        const bonus = s.chests.pending.find((c) => c.kind === "bonus" && c.createdAt === 0);
        if (bonus && bonusAllowed(s.chests.placedTimes, now)) {
          bonus.createdAt = now;
          s.chests.placedTimes.push(now);
          fx.chest = { ...bonus };
          break;
        }
        if (chestAllowed({ seenSinceLast: s.chests.seenSinceLast, placedTimes: s.chests.placedTimes, now }) && rand() < 0.35) {
          const kind = chestKindFor(action.mention, festivalOn(s, now), rand());
          const chest = { id: `c${now.toString(36)}${Math.floor(rand() * 1e6).toString(36)}`, kind, createdAt: now };
          s.chests.pending = [...s.chests.pending.filter((c) => now - c.createdAt < 36e5 || c.createdAt === 0), chest].slice(-12);
          s.chests.placedTimes.push(now);
          s.chests.seenSinceLast = 0;
          fx.chest = chest;
        }
        break;
      }
      case "openChest": {
        const chest = s.chests.pending.find((c) => c.id === action.id && c.createdAt > 0);
        if (!chest) {
          fx.error = "noChest";
          break;
        }
        s.chests.pending = s.chests.pending.filter((c) => c.id !== chest.id);
        const r = chestReward(chest.kind, isRunning(s, now), [rand(), rand(), rand()]);
        addSeeds(s, r.seeds);
        addXp(s, r.xp);
        if (r.item) s.inventory[r.item] = (s.inventory[r.item] ?? 0) + 1;
        s.chests.opened += 1;
        up("happiness", 3);
        if (chest.kind === "golden") {
          s.chests.goldenOpened += 1;
          quest(s, "golden1", fx);
        }
        quest(s, "open5", fx);
        fx.opened = { kind: chest.kind, seeds: r.seeds, item: r.item };
        logLine(s, now, chest.kind === "golden" ? "log.golden" : "log.chest", r.seeds);
        const extra = [];
        if (chest.kind === "bonus") extra.push("bonusChest");
        if (chest.kind === "golden" && festivalOn(s, now)) extra.push("festivalChest");
        checkAchievements(s, fx, extra);
        break;
      }
      case "feed": {
        const food = action.food ?? ["yogurt", "carrot", "sunflower"].find((f) => (s.inventory[f] ?? 0) > 0);
        if (food && (s.inventory[food] ?? 0) > 0) {
          s.inventory[food] -= 1;
          const item = itemById(food);
          up("hunger", item?.power ?? 10);
          up("happiness", 4);
        } else {
          up("hunger", 10);
        }
        s.counters.feeds += 1;
        addXp(s, 2);
        quest(s, "feed2", fx);
        checkAchievements(s, fx);
        break;
      }
      case "play": {
        const toyPower = Math.max(0, ...ITEMS.filter((i) => i.kind === "toy" && s.owned.includes(i.id)).map((i) => i.power ?? 0));
        up("happiness", 12 + toyPower);
        up("energy", -6);
        up("hunger", -3);
        s.counters.plays += 1;
        addXp(s, 3);
        checkAchievements(s, fx);
        break;
      }
      case "clean":
        up("cleanliness", 35);
        s.counters.cleans += 1;
        addXp(s, 2);
        checkAchievements(s, fx);
        break;
      case "buy": {
        const item = itemById(action.id);
        if (!item) {
          fx.error = "unknownItem";
          break;
        }
        if (item.kind !== "food" && s.owned.includes(item.id)) {
          fx.error = "owned";
          break;
        }
        if (s.seeds < item.price) {
          fx.error = "noSeeds";
          break;
        }
        s.seeds -= item.price;
        if (item.kind === "food") s.inventory[item.id] = (s.inventory[item.id] ?? 0) + 1;
        else s.owned = [...s.owned, item.id];
        if (item.kind === "hat" && !s.pet.hat) s.pet.hat = item.id;
        if (item.kind === "wheel") s.pet.wheel = item.id;
        checkAchievements(s, fx, ["firstBuy"]);
        break;
      }
      case "equip":
        if (action.id === null || s.owned.includes(action.id)) s.pet[action.slot] = action.id;
        break;
      case "rename":
        s.pet.name = action.name.trim().slice(0, 16) || s.pet.name;
        break;
      case "status": {
        const prevSnap = s.sync;
        const next = action.snap;
        if (next.reach === "ok") {
          const xTabOpen = now - s.lastXSeen < X_TAB_FRESH_MS;
          const e = syncEarnings({ prev: prevSnap, next, now, xTabOpen, hourStart: s.earn.hourStart, earnedThisHour: s.earn.earnedThisHour });
          s.earn.hourStart = e.hourStart;
          s.earn.earnedThisHour = e.earnedThisHour;
          if (e.seeds > 0) {
            addSeeds(s, e.seeds);
            s.earn.totalRunSeeds += e.seeds;
            addXp(s, Math.ceil(e.seeds / 5));
            quest(s, "runOnline", fx);
            logLine(s, now, "log.run", e.seeds);
          }
          if (newBlock(prevSnap, next) && xTabOpen && !s.chests.pending.some((c) => c.kind === "bonus" && c.createdAt === 0)) {
            s.chests.pending = [...s.chests.pending, { id: `b${next.blockHeight}`, kind: "bonus", createdAt: 0 }];
            logLine(s, now, "log.block");
          }
          s.sync = next;
        } else {
          s.sync = { ...prevSnap, reach: "error", retryAfter: next.retryAfter };
        }
        checkAchievements(s, fx);
        break;
      }
      case "events": {
        const r = applyFestival({ events: action.events, seenIds: s.festival.seenIds, installedAt: s.createdAt, until: s.festival.until, now });
        s.festival = { until: r.until, seenIds: r.seenIds };
        if (r.started) logLine(s, now, "log.festival");
        break;
      }
      case "settings":
        s.settings = { ...s.settings, ...action.patch };
        break;
      case "hidePath": {
        const set = new Set(s.settings.hiddenPaths);
        if (action.hidden) set.add(action.path);
        else set.delete(action.path);
        s.settings.hiddenPaths = [...set];
        break;
      }
      case "shared":
        s.counters.shares += 1;
        checkAchievements(s, fx);
        break;
      case "replace":
        return { state: { ...action.state, lastTick: now }, fx };
    }
    return { state: s, fx };
  }

  // shared/state.ts
  var STORAGE_KEY = "squeekpal";
  function emptySnapshot() {
    return {
      fetchedAt: 0,
      coreStatus: null,
      freshness: null,
      rpmMilli: null,
      speedMmPerSecond: null,
      distanceMm: null,
      cumulativeWorkUnits: null,
      blockHeight: null,
      blockProgress: null,
      reach: "never",
      retryAfter: 0
    };
  }
  function defaultState(now, lang = "en") {
    return {
      version: 2,
      createdAt: now,
      lastTick: now,
      pet: {
        name: "Pip",
        stats: { hunger: 80, happiness: 80, energy: 80, cleanliness: 80 },
        xp: 0,
        hat: null,
        wheel: null
      },
      seeds: 10,
      inventory: { sunflower: 2 },
      owned: [],
      chests: { seenSinceLast: 0, placedTimes: [], pending: [], opened: 0, goldenOpened: 0 },
      earn: { hourStart: now, earnedThisHour: 0, totalRunSeeds: 0 },
      counters: { feeds: 0, plays: 0, cleans: 0, shares: 0, questsDone: 0, seedsTotal: 0 },
      quests: { day: -1, list: [] },
      achievements: [],
      festival: { until: 0, seenIds: [] },
      sync: emptySnapshot(),
      lastXSeen: 0,
      settings: {
        lang,
        chestsOn: true,
        palOn: true,
        minimized: false,
        hiddenPaths: [],
        pos: null
      },
      log: []
    };
  }
  function clampNum(v, lo, hi, fallback) {
    const n = typeof v === "number" && Number.isFinite(v) ? v : fallback;
    return Math.min(hi, Math.max(lo, n));
  }
  function record(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v) ? v : {};
  }
  var list = (v) => Array.isArray(v) ? v : [];
  function sanitizeV2(raw, now) {
    const r = record(raw);
    const s = defaultState(now);
    const time = (v, fallback = 0, hi = now) => clampNum(v, 0, hi, fallback);
    const count = (v, fallback = 0, hi = 1e9) => Math.floor(clampNum(v, 0, hi, fallback));
    const pet = record(r.pet), stats = record(pet.stats);
    s.createdAt = time(r.createdAt, now);
    s.lastTick = time(r.lastTick, now);
    s.lastXSeen = time(r.lastXSeen);
    s.pet.name = typeof pet.name === "string" && pet.name.trim() ? pet.name.trim().slice(0, 16) : s.pet.name;
    for (const k of Object.keys(s.pet.stats)) s.pet.stats[k] = clampNum(stats[k], 0, 100, s.pet.stats[k]);
    s.pet.xp = count(pet.xp);
    for (const slot of ["hat", "wheel"]) {
      const id = pet[slot];
      s.pet[slot] = typeof id === "string" && itemById(id)?.kind === slot ? id : null;
    }
    s.seeds = count(r.seeds, s.seeds);
    if (r.inventory !== void 0 && r.inventory !== null && typeof r.inventory === "object" && !Array.isArray(r.inventory)) {
      const inventory = record(r.inventory);
      s.inventory = Object.fromEntries(ITEMS.filter((i) => i.kind === "food" && Object.hasOwn(inventory, i.id)).map((i) => [i.id, count(inventory[i.id], 0, 1e6)]));
    }
    s.owned = [...new Set(list(r.owned).filter((id) => typeof id === "string" && !!itemById(id) && itemById(id).kind !== "food"))];
    const chests = record(r.chests);
    s.chests.seenSinceLast = count(chests.seenSinceLast);
    s.chests.opened = count(chests.opened);
    s.chests.goldenOpened = count(chests.goldenOpened);
    s.chests.placedTimes = list(chests.placedTimes).filter((v) => typeof v === "number" && Number.isFinite(v) && v >= now - 36e5 && v <= now).slice(-12);
    const chestIds = /* @__PURE__ */ new Set();
    for (const entry of list(chests.pending).slice(-12)) {
      const c = record(entry);
      if (typeof c.id !== "string" || !/^[a-z0-9]{1,64}$/.test(c.id) || chestIds.has(c.id)) continue;
      if (c.kind !== "normal" && c.kind !== "golden" && c.kind !== "bonus") continue;
      if (typeof c.createdAt !== "number" || !Number.isFinite(c.createdAt) || c.createdAt < 0 || c.createdAt > now) continue;
      chestIds.add(c.id);
      s.chests.pending.push({ id: c.id, kind: c.kind, createdAt: c.createdAt });
    }
    const earn = record(r.earn);
    s.earn = { hourStart: time(earn.hourStart, now), earnedThisHour: count(earn.earnedThisHour, 0, 300), totalRunSeeds: count(earn.totalRunSeeds) };
    const counters = record(r.counters);
    for (const k of Object.keys(s.counters)) s.counters[k] = count(counters[k]);
    const quests = record(r.quests);
    if (typeof quests.day === "number" && Number.isInteger(quests.day) && quests.day >= 0 && quests.day <= squeekDay(now)) {
      s.quests.day = quests.day;
      s.quests.list = questsForDay(quests.day).map((q) => {
        const saved = list(quests.list).map(record).find((v) => v.id === q.id);
        const progress = count(saved?.progress, 0, q.goal);
        return { ...q, progress, done: progress >= q.goal };
      });
    }
    s.achievements = ACHIEVEMENTS.filter((id) => list(r.achievements).includes(id));
    const festival = record(r.festival);
    s.festival.until = time(festival.until, 0, now + 36e5);
    s.festival.seenIds = [...new Set(list(festival.seenIds).filter((id) => typeof id === "string" && id.length > 0 && id.length <= 256))].slice(-200);
    const sync = record(r.sync);
    s.sync.fetchedAt = time(sync.fetchedAt);
    s.sync.retryAfter = time(sync.retryAfter, 0, Number.MAX_SAFE_INTEGER);
    s.sync.coreStatus = ["ACTIVE", "IDLE", "COUNTER_FAULT"].includes(sync.coreStatus) ? sync.coreStatus : null;
    s.sync.freshness = typeof sync.freshness === "string" && /^(online|stale|offline|unknown)$/i.test(sync.freshness) ? sync.freshness : null;
    for (const k of ["rpmMilli", "speedMmPerSecond", "distanceMm", "cumulativeWorkUnits", "blockHeight", "blockProgress"]) {
      const v = sync[k];
      s.sync[k] = typeof v === "string" && /^\d+(\.\d+)?$/.test(v) && v.length <= 100 ? v : null;
    }
    s.sync.reach = sync.reach === "ok" || sync.reach === "error" ? sync.reach : "never";
    const settings = record(r.settings);
    s.settings.lang = settings.lang === "vi" ? "vi" : "en";
    for (const k of ["chestsOn", "palOn", "minimized"]) if (typeof settings[k] === "boolean") s.settings[k] = settings[k];
    s.settings.hiddenPaths = [...new Set(list(settings.hiddenPaths).filter((p) => typeof p === "string" && p.startsWith("/") && p.length <= 2048))].slice(-200);
    const pos = record(settings.pos);
    if (typeof pos.x === "number" && Number.isFinite(pos.x) && typeof pos.y === "number" && Number.isFinite(pos.y)) {
      s.settings.pos = { x: count(pos.x, 0, 1e5), y: count(pos.y, 0, 1e5) };
    }
    const logKeys = ["log.chest", "log.golden", "log.run", "log.block", "log.festival"];
    s.log = list(r.log).map(record).filter((l) => typeof l.key === "string" && logKeys.includes(l.key)).slice(0, 12).map((l) => ({ t: time(l.t), key: l.key, ...l.n === void 0 ? {} : { n: count(l.n) } }));
    return s;
  }
  function migrate(raw, now) {
    if (!raw || typeof raw !== "object") return defaultState(now);
    const r = raw;
    if (r.version === 1) {
      const v1 = raw;
      const s = defaultState(now, v1.lang === "vi" ? "vi" : "en");
      s.pet.name = typeof v1.name === "string" && v1.name.trim() ? v1.name.slice(0, 16) : s.pet.name;
      for (const k of Object.keys(s.pet.stats)) {
        s.pet.stats[k] = clampNum(v1.stats?.[k], 0, 100, s.pet.stats[k]);
      }
      s.pet.xp = clampNum(v1.xp, 0, 1e9, 0);
      s.seeds = clampNum(v1.seeds, 0, 1e9, s.seeds);
      if (v1.inventory && typeof v1.inventory === "object") s.inventory = { ...v1.inventory };
      return sanitizeV2(s, now);
    }
    if (r.version === 2) {
      return sanitizeV2(raw, now);
    }
    return defaultState(now);
  }

  // shared/api.ts
  var API_BASE = "https://api.squeekchain.com/v1";
  function get(obj, path) {
    let cur = obj;
    for (const key of path.split(".")) {
      if (!cur || typeof cur !== "object") return void 0;
      cur = cur[key];
    }
    return cur;
  }
  function readValue(v) {
    if (v === null || v === void 0) return null;
    if (typeof v === "string") return v.toLowerCase() === "unavailable" ? null : v;
    if (typeof v === "number" && Number.isFinite(v)) return String(v);
    if (typeof v === "object") {
      const o = v;
      if (typeof o.status === "string" && o.status.toLowerCase() === "unavailable") return null;
      if ("value" in o) return readValue(o.value);
    }
    return null;
  }
  function parseStatus(body, now) {
    const root = body && typeof body === "object" && "data" in body && !("measurement" in body) ? body.data : body;
    const f = (p) => readValue(get(root, p));
    return {
      fetchedAt: now,
      coreStatus: f("measurement.coreStatus"),
      freshness: f("measurement.freshness"),
      rpmMilli: f("measurement.rpmMilli"),
      speedMmPerSecond: f("measurement.speedMmPerSecond"),
      distanceMm: f("measurement.distanceMm"),
      cumulativeWorkUnits: f("measurement.cumulativeWorkUnits"),
      blockHeight: f("builder.anchor.blockHeight"),
      blockProgress: f("builder.anchor.blockProgress"),
      reach: "ok",
      retryAfter: 0
    };
  }
  function toMs(v) {
    if (typeof v === "number") return v < 1e12 ? v * 1e3 : v;
    if (typeof v === "string") {
      if (/^\d+$/.test(v)) return toMs(Number(v));
      const t = Date.parse(v);
      return Number.isNaN(t) ? 0 : t;
    }
    return 0;
  }
  function parseEvents(body) {
    const root = body;
    const list2 = Array.isArray(root) ? root : get(root, "events") ?? get(root, "data") ?? get(root, "items");
    if (!Array.isArray(list2)) return [];
    const out = [];
    for (const e of list2) {
      if (!e || typeof e !== "object") continue;
      const o = e;
      const id = o.id ?? o.eventId;
      const type = o.type ?? o.kind ?? o.name;
      const at = toMs(o.occurredAt ?? o.recordedAt ?? o.timestamp ?? o.createdAt ?? o.time ?? o.observedAt);
      if ((typeof id === "string" || typeof id === "number") && typeof type === "string" && at > 0) {
        out.push({ id: String(id), type, at });
      }
    }
    return out;
  }
  function retryAfterMs(header, now) {
    if (!header) return 12e4;
    if (/^\d+$/.test(header.trim())) return Number(header.trim()) * 1e3;
    const t = Date.parse(header);
    return Number.isNaN(t) ? 12e4 : Math.max(0, t - now);
  }
  async function fetchStatus(fetcher, now) {
    const fail = (retryAfter = 0) => ({ ...emptySnapshot(), reach: "error", retryAfter });
    try {
      const res = await fetcher(`${API_BASE}/status`, { cache: "no-store", credentials: "omit" });
      if (res.status === 429) return fail(now + retryAfterMs(res.headers.get("Retry-After"), now));
      if (!res.ok) return fail();
      return parseStatus(await res.json(), now);
    } catch {
      return fail();
    }
  }
  async function fetchEvents(fetcher, now) {
    try {
      const res = await fetcher(`${API_BASE}/events?category=measurement&limit=20`, { cache: "no-store", credentials: "omit" });
      if (res.status === 429) return { events: [], retryAfter: now + retryAfterMs(res.headers.get("Retry-After"), now) };
      if (!res.ok) return null;
      return { events: parseEvents(await res.json()), retryAfter: 0 };
    } catch {
      return null;
    }
  }

  // extension/background.ts
  var STATUS_ALARM = "squeekpal-status";
  var EVENTS_ALARM = "squeekpal-events";
  var queue = Promise.resolve();
  async function load() {
    const got = await chrome.storage.local.get(STORAGE_KEY);
    const raw = got[STORAGE_KEY];
    if (!raw) {
      const lang = (chrome.i18n?.getUILanguage?.() ?? "en").toLowerCase().startsWith("vi") ? "vi" : "en";
      return defaultState(Date.now(), lang);
    }
    return migrate(raw, Date.now());
  }
  function apply(action) {
    const job = queue.then(async () => {
      const prev = await load();
      const { state, fx } = reduce(prev, action, { now: Date.now(), rand: Math.random });
      await chrome.storage.local.set({ [STORAGE_KEY]: state });
      return fx;
    });
    queue = job.catch(() => void 0);
    return job;
  }
  async function pollStatus() {
    const s = await load();
    if (s.sync.retryAfter > Date.now()) return;
    const snap = await fetchStatus(fetch.bind(globalThis), Date.now());
    await apply({ type: "status", snap });
  }
  async function pollEvents() {
    const s = await load();
    if (s.sync.retryAfter > Date.now()) return;
    const r = await fetchEvents(fetch.bind(globalThis), Date.now());
    if (!r) return;
    if (r.retryAfter) {
      await apply({ type: "status", snap: { ...s.sync, reach: "error", retryAfter: r.retryAfter } });
      return;
    }
    await apply({ type: "events", events: r.events });
  }
  function ensureAlarms() {
    chrome.alarms.create(STATUS_ALARM, { periodInMinutes: 1, delayInMinutes: 0.1 });
    chrome.alarms.create(EVENTS_ALARM, { periodInMinutes: 5, delayInMinutes: 0.2 });
  }
  chrome.runtime.onInstalled.addListener(async () => {
    const got = await chrome.storage.local.get(STORAGE_KEY);
    if (!got[STORAGE_KEY]) await chrome.storage.local.set({ [STORAGE_KEY]: await load() });
    ensureAlarms();
  });
  chrome.runtime.onStartup.addListener(ensureAlarms);
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === STATUS_ALARM) void pollStatus();
    if (alarm.name === EVENTS_ALARM) void pollEvents();
  });
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg && msg.type === "squeekpal:dispatch" && msg.action && typeof msg.action.type === "string") {
      apply(msg.action).then(sendResponse, () => sendResponse({}));
      return true;
    }
    return false;
  });
})();
