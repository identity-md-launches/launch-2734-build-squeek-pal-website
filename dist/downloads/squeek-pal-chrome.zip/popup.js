"use strict";
(() => {
  // shared/catalog.ts
  var ITEMS = [
    { id: "sunflower", kind: "food", price: 4, power: 15 },
    { id: "carrot", kind: "food", price: 8, power: 25 },
    { id: "yogurt", kind: "food", price: 14, power: 40 },
    { id: "chew", kind: "toy", price: 20, power: 6 },
    { id: "ball", kind: "toy", price: 30, power: 9 },
    { id: "tunnel", kind: "toy", price: 45, power: 12 },
    { id: "acorn", kind: "hat", price: 25, colors: ["#8a5a2b", "#c98b45"] },
    { id: "beanie", kind: "hat", price: 35, colors: ["#3b7dd8", "#f2f2f2"] },
    { id: "party", kind: "hat", price: 50, colors: ["#e0457b", "#ffd447"] },
    { id: "crown", kind: "hat", price: 90, colors: ["#f2b705", "#fff1a8"] },
    { id: "mint", kind: "wheel", price: 30, colors: ["#3fb68b", "#bff0dc"] },
    { id: "sunset", kind: "wheel", price: 45, colors: ["#e8743b", "#ffd0a8"] },
    { id: "golden", kind: "wheel", price: 120, colors: ["#d4a017", "#fff0a0"] }
  ];
  var DEFAULT_WHEEL_COLORS = ["#8c8c96", "#d9d9e0"];
  function itemById(id) {
    return ITEMS.find((i) => i.id === id);
  }
  function itemsOfKind(kind) {
    return ITEMS.filter((i) => i.kind === kind);
  }

  // shared/art.ts
  var PAL = {
    o: "#e39a4b",
    // fur
    O: "#c9762f",
    // fur shade
    c: "#fbe3c0",
    // belly
    p: "#f2a3a8",
    // ear and paw pink
    k: "#2b1d14",
    // eye
    w: "#ffffff",
    // eye shine
    n: "#e86f86"
    // nose
  };
  var OUTLINE = "#4a2a12";
  var BODY = [
    "..........oo....",
    ".........oppo...",
    "....ooooooooo...",
    "...ooooooooooo..",
    "..OoooooooookwO.",
    "..Ooooooooookkon",
    ".OOoocccccccooo.",
    ".OOocccccccccoo.",
    ".OOocccccccccco.",
    "..OOccccccccoo.."
  ];
  var FEET_A = ["...pp.....pp....", "................"];
  var FEET_B = ["....pp...pp.....", "................"];
  var FEET_SIT = ["..pppp...pppp...", "................"];
  var SPRITE_W = 28;
  var SPRITE_H = 26;
  function px(ctx, x, y, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, 1, 1);
  }
  function drawMap(ctx, rows, ox, oy, palette, flip = false) {
    const w = rows[0].length;
    const filled = /* @__PURE__ */ new Set();
    rows.forEach(
      (row, y) => [...row].forEach((ch, x) => {
        if (ch !== ".") filled.add(`${flip ? w - 1 - x : x},${y}`);
      })
    );
    for (const key of filled) {
      const [x, y] = key.split(",").map(Number);
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        if (!filled.has(`${x + dx},${y + dy}`)) px(ctx, ox + x + dx, oy + y + dy, OUTLINE);
      }
    }
    rows.forEach(
      (row, y) => [...row].forEach((ch, x) => {
        if (ch === ".") return;
        px(ctx, ox + (flip ? w - 1 - x : x), oy + y, palette[ch] ?? ch);
      })
    );
  }
  function drawHat(ctx, hat, ox, oy, flip) {
    const item = itemById(hat);
    if (!item?.colors) return;
    const [a, b] = item.colors;
    const maps = {
      acorn: ["..bbbb..", ".aaaaaa.", "aaaaaaaa", ".aaaaaa."],
      beanie: ["...bb...", "..aaaa..", ".aaaaaa.", "bbbbbbbb"],
      party: ["...b....", "...a....", "..aba...", ".aaaab..", "abaaaaab"],
      crown: ["a..a..a.", "ab.a.ba.", "aaaaaaaa", "abababa."]
    };
    const rows = maps[hat];
    if (!rows) return;
    const pal = { a, b };
    const x = flip ? ox + 16 - 13 : ox + 5;
    drawMap(ctx, rows, x, oy - rows.length + 2, pal, flip);
  }
  function drawWheel(ctx, wheel, frame) {
    const colors = wheel && itemById(wheel)?.colors || DEFAULT_WHEEL_COLORS;
    const cx = 14;
    const cy = 12.5;
    const r = 12;
    ctx.fillStyle = colors[1];
    for (let a = 0; a < 360; a += 4) {
      const rad = a * Math.PI / 180;
      ctx.fillRect(Math.round(cx + Math.cos(rad) * r - 0.5), Math.round(cy + Math.sin(rad) * r - 0.5), 1, 1);
    }
    ctx.fillStyle = colors[0];
    for (let a = 0; a < 360; a += 3) {
      const rad = a * Math.PI / 180;
      ctx.fillRect(Math.round(cx + Math.cos(rad) * (r - 1) - 0.5), Math.round(cy + Math.sin(rad) * (r - 1) - 0.5), 1, 1);
    }
    for (let i = 0; i < 8; i++) {
      const rad = (i * 45 + frame * 11) * Math.PI / 180;
      ctx.fillRect(Math.round(cx + Math.cos(rad) * (r - 2.5) - 0.5), Math.round(cy + Math.sin(rad) * (r - 2.5) - 0.5), 1, 1);
    }
    ctx.fillStyle = colors[0];
    ctx.fillRect(cx - 1, cy, 2, 1);
    ctx.fillRect(cx - 5, SPRITE_H - 1, 10, 1);
  }
  function drawPal(ctx, d) {
    ctx.imageSmoothingEnabled = false;
    const flip = !!d.flip;
    if (d.pose === "run") drawWheel(ctx, d.wheel, d.frame);
    const bob = d.pose === "run" ? d.frame % 2 : d.pose === "walk" ? d.frame % 2 : 0;
    const ox = d.pose === "run" ? 6 : d.x ?? 6;
    const oy = d.pose === "run" ? 8 + bob : 12 + bob * 0;
    let body2 = BODY.slice();
    if (d.pose === "nap") {
      body2 = body2.map((r, i) => i === 4 ? r.replace("kw", "oo") : i === 5 ? r.replace("kk", "Ok") : r);
    }
    if (d.mood === "grumpy" && d.pose !== "nap") {
      body2 = body2.map((r, i) => i === 3 ? r.slice(0, 11) + "kk" + r.slice(13) : r);
    }
    const feet = d.pose === "nap" || d.pose === "sit" || d.pose === "eat" ? FEET_SIT : d.frame % 2 ? FEET_B : FEET_A;
    drawMap(ctx, [...body2, ...feet], ox, oy, PAL, flip);
    if (d.hat) drawHat(ctx, d.hat, ox, oy, flip);
    if (d.pose === "eat") {
      const sx = flip ? ox - 2 : ox + 16;
      const seed = d.frame % 2 ? [".s", "ss", "s."] : ["s.", "ss", ".s"];
      drawMap(ctx, seed, sx, oy + 5, { s: "#3a3a3a" });
    }
    if (d.pose === "nap") {
      const zx = flip ? ox - 3 : ox + 16;
      const zy = oy - 4 - d.frame % 3;
      drawMap(ctx, ["zzz", "..z", ".z.", "zzz"], zx, zy, { z: "#6b7cff" });
    }
    if (d.mood === "happy" && d.pose === "sit" && d.frame % 4 === 0) {
      drawMap(ctx, [".h.h.", "hhhhh", ".hhh.", "..h.."], flip ? ox - 4 : ox + 15, oy - 6, { h: "#e0457b" });
    }
  }
  function palCanvas(doc, scale, d) {
    const c = doc.createElement("canvas");
    c.width = SPRITE_W * scale;
    c.height = SPRITE_H * scale;
    const ctx = c.getContext("2d");
    ctx.scale(scale, scale);
    drawPal(ctx, d);
    return c;
  }

  // shared/i18n.ts
  var en = {
    "stat.hunger": "Hunger",
    "stat.happiness": "Happiness",
    "stat.energy": "Energy",
    "stat.cleanliness": "Cleanliness",
    "stage.pup": "Pup",
    "stage.junior": "Junior",
    "stage.adult": "Adult",
    "stage.legend": "Wheel Legend",
    "mood.happy": "Happy",
    "mood.ok": "Content",
    "mood.grumpy": "Grumpy",
    "act.feed": "Feed",
    "act.play": "Play",
    "act.clean": "Clean",
    "act.minimize": "Minimise",
    "act.hidePage": "Hide on this page",
    "act.close": "Close",
    "act.open": "Open {name}'s panel",
    "act.restore": "Show {name}",
    "act.openChest": "Open chest",
    "act.openGolden": "Open golden chest",
    "act.buy": "Buy",
    "act.equip": "Wear",
    "act.unequip": "Take off",
    "act.share": "Share my Squeek Pal",
    "act.card": "Download pet card",
    "act.export": "Copy save code",
    "act.import": "Load save code",
    "act.rename": "Rename",
    "label.seeds": "Seeds",
    "label.xp": "XP",
    "label.owned": "Owned",
    "label.wearing": "Wearing",
    "label.price": "{n} Seeds",
    "label.have": "You have {n}",
    "label.nextStage": "{n} XP to next stage",
    "label.maxStage": "Top stage reached",
    "label.questReset": "New quests at 12:00 UTC",
    "label.saveCode": "Save code",
    "label.name": "Pal name",
    "label.lang": "Language",
    "label.inventory": "Food",
    "label.noWheel": "Plain wheel",
    "label.noHat": "No hat",
    "label.waiting": "{n} waiting",
    "tab.pet": "Pet",
    "tab.shop": "Shop",
    "tab.wardrobe": "Wardrobe",
    "tab.quests": "Quests",
    "tab.settings": "Settings",
    "kind.food": "Food",
    "kind.toy": "Toys",
    "kind.hat": "Hats",
    "kind.wheel": "Wheel skins",
    "set.palOn": "Show the pal on x.com",
    "set.chestsOn": "Place seed chests on posts",
    "set.hidden": "Hidden on {n} pages",
    "set.unhide": "Show on all pages again",
    "set.importOk": "Save loaded.",
    "set.importBad": "That code did not load. Paste the whole code, starting with SQK2.",
    "set.copied": "Code copied.",
    "live.title": "Squeektoshi live",
    "live.running": "Running now. Your pal runs too: 1 Seed per wheel turn, chests worth 2x.",
    "live.idle": "Squeektoshi is resting. Your pal naps and recovers energy 2x faster.",
    "live.unknown": "Wheel status unknown right now.",
    "live.offline": "Can't reach the wheel right now",
    "live.waiting": "Checking the wheel",
    "live.speed": "Speed",
    "live.distance": "Distance",
    "live.block": "Block",
    "live.festival": "Golden chest festival until {t}",
    "live.earned": "{n}/300 Seeds from running this hour",
    "live.gentle": "Squeektoshi runs when it wants to. Nothing here asks it to.",
    "chest.got": "+{n} Seeds",
    "chest.item": "and a {item}",
    "chest.normal": "Seed chest",
    "chest.golden": "Golden chest",
    "chest.bonus": "Block bonus chest",
    "err.noSeeds": "Not enough Seeds yet.",
    "err.owned": "Already yours.",
    "quest.open5": "Open 5 chests",
    "quest.golden1": "Find a golden chest",
    "quest.runOnline": "Be online during a run",
    "quest.feed2": "Feed your pal twice",
    "quest.reward": "+20 Seeds, +15 XP",
    "quest.done": "Done",
    "ach.title": "Achievements",
    "ach.count": "{n} of {m} unlocked",
    "log.chest": "Opened a chest: +{n} Seeds",
    "log.golden": "Opened a golden chest: +{n} Seeds",
    "log.run": "Ran with Squeektoshi: +{n} Seeds",
    "log.block": "New Squeek block: a bonus chest is on its way",
    "log.festival": "A wheel record started a golden chest festival",
    "share.text": "Meet {name}, my {stage} Squeek Pal. It runs with Squeektoshi, the real hamster powering Squeekchain.",
    "card.tagline": "Runs with Squeektoshi on Squeekchain",
    "privacy": "Chests only read visible post text, on your device. Nothing is posted, liked or sent anywhere.",
    "item.sunflower": "Sunflower seed",
    "item.carrot": "Carrot slice",
    "item.yogurt": "Yogurt drop",
    "item.chew": "Chew stick",
    "item.ball": "Grass ball",
    "item.tunnel": "Tunnel",
    "item.acorn": "Acorn cap",
    "item.beanie": "Blue beanie",
    "item.party": "Party hat",
    "item.crown": "Tiny crown",
    "item.mint": "Mint wheel",
    "item.sunset": "Sunset wheel",
    "item.golden": "Golden wheel",
    "ach.firstChest": "First chest",
    "ach.chests10": "10 chests",
    "ach.chests50": "50 chests",
    "ach.chests100": "100 chests",
    "ach.firstGolden": "Golden find",
    "ach.golden5": "5 golden chests",
    "ach.firstFeed": "First meal",
    "ach.feeds25": "25 meals",
    "ach.plays25": "25 play times",
    "ach.cleans10": "10 baths",
    "ach.junior": "Grew to Junior",
    "ach.adult": "Grew to Adult",
    "ach.legend": "Wheel Legend",
    "ach.firstRunSeed": "Ran with Squeektoshi",
    "ach.runSeeds500": "500 Seeds from running",
    "ach.firstBuy": "First purchase",
    "ach.allHats": "Every hat",
    "ach.firstQuest": "First quest",
    "ach.quests10": "10 quests",
    "ach.festivalChest": "Festival chest",
    "ach.bonusChest": "Block bonus chest",
    "ach.firstShare": "Shared your pal"
  };
  var vi = {
    "stat.hunger": "No b\u1EE5ng",
    "stat.happiness": "Vui v\u1EBB",
    "stat.energy": "N\u0103ng l\u01B0\u1EE3ng",
    "stat.cleanliness": "S\u1EA1ch s\u1EBD",
    "stage.pup": "B\xE9 con",
    "stage.junior": "Thi\u1EBFu ni\xEAn",
    "stage.adult": "Tr\u01B0\u1EDFng th\xE0nh",
    "stage.legend": "Huy\u1EC1n tho\u1EA1i b\xE1nh xe",
    "mood.happy": "Vui",
    "mood.ok": "B\xECnh th\u01B0\u1EDDng",
    "mood.grumpy": "C\xE1u k\u1EC9nh",
    "act.feed": "Cho \u0103n",
    "act.play": "Ch\u01A1i",
    "act.clean": "T\u1EAFm",
    "act.minimize": "Thu nh\u1ECF",
    "act.hidePage": "\u1EA8n tr\xEAn trang n\xE0y",
    "act.close": "\u0110\xF3ng",
    "act.open": "M\u1EDF b\u1EA3ng c\u1EE7a {name}",
    "act.restore": "Hi\u1EC7n {name}",
    "act.openChest": "M\u1EDF r\u01B0\u01A1ng",
    "act.openGolden": "M\u1EDF r\u01B0\u01A1ng v\xE0ng",
    "act.buy": "Mua",
    "act.equip": "M\u1EB7c",
    "act.unequip": "C\u1EDFi ra",
    "act.share": "Chia s\u1EBB Squeek Pal c\u1EE7a t\xF4i",
    "act.card": "T\u1EA3i th\u1EBB th\xFA c\u01B0ng",
    "act.export": "Sao ch\xE9p m\xE3 l\u01B0u",
    "act.import": "N\u1EA1p m\xE3 l\u01B0u",
    "act.rename": "\u0110\u1ED5i t\xEAn",
    "label.seeds": "H\u1EA1t",
    "label.xp": "XP",
    "label.owned": "\u0110\xE3 c\xF3",
    "label.wearing": "\u0110ang m\u1EB7c",
    "label.price": "{n} H\u1EA1t",
    "label.have": "B\u1EA1n c\xF3 {n}",
    "label.nextStage": "C\xF2n {n} XP \u0111\u1EC3 l\xEAn c\u1EA5p",
    "label.maxStage": "\u0110\xE3 \u0111\u1EA1t c\u1EA5p cao nh\u1EA5t",
    "label.questReset": "Nhi\u1EC7m v\u1EE5 m\u1EDBi l\xFAc 12:00 UTC",
    "label.saveCode": "M\xE3 l\u01B0u",
    "label.name": "T\xEAn th\xFA c\u01B0ng",
    "label.lang": "Ng\xF4n ng\u1EEF",
    "label.inventory": "\u0110\u1ED3 \u0103n",
    "label.noWheel": "B\xE1nh xe th\u01B0\u1EDDng",
    "label.noHat": "Kh\xF4ng \u0111\u1ED9i m\u0169",
    "label.waiting": "{n} \u0111ang ch\u1EDD",
    "tab.pet": "Th\xFA c\u01B0ng",
    "tab.shop": "C\u1EEDa h\xE0ng",
    "tab.wardrobe": "T\u1EE7 \u0111\u1ED3",
    "tab.quests": "Nhi\u1EC7m v\u1EE5",
    "tab.settings": "C\xE0i \u0111\u1EB7t",
    "kind.food": "\u0110\u1ED3 \u0103n",
    "kind.toy": "\u0110\u1ED3 ch\u01A1i",
    "kind.hat": "M\u0169",
    "kind.wheel": "M\xE0u b\xE1nh xe",
    "set.palOn": "Hi\u1EC7n th\xFA c\u01B0ng tr\xEAn x.com",
    "set.chestsOn": "\u0110\u1EB7t r\u01B0\u01A1ng h\u1EA1t tr\xEAn b\xE0i \u0111\u0103ng",
    "set.hidden": "\u0110ang \u1EA9n tr\xEAn {n} trang",
    "set.unhide": "Hi\u1EC7n l\u1EA1i tr\xEAn m\u1ECDi trang",
    "set.importOk": "\u0110\xE3 n\u1EA1p b\u1EA3n l\u01B0u.",
    "set.importBad": "M\xE3 kh\xF4ng h\u1EE3p l\u1EC7. H\xE3y d\xE1n to\xE0n b\u1ED9 m\xE3, b\u1EAFt \u0111\u1EA7u b\u1EB1ng SQK2.",
    "set.copied": "\u0110\xE3 sao ch\xE9p m\xE3.",
    "live.title": "Squeektoshi tr\u1EF1c ti\u1EBFp",
    "live.running": "\u0110ang ch\u1EA1y. Th\xFA c\u01B0ng c\u1EE7a b\u1EA1n c\u0169ng ch\u1EA1y: 1 H\u1EA1t m\u1ED7i v\xF2ng, r\u01B0\u01A1ng gi\xE1 tr\u1ECB g\u1EA5p \u0111\xF4i.",
    "live.idle": "Squeektoshi \u0111ang ngh\u1EC9. Th\xFA c\u01B0ng ng\u1EE7 v\xE0 h\u1ED3i n\u0103ng l\u01B0\u1EE3ng nhanh g\u1EA5p \u0111\xF4i.",
    "live.unknown": "Ch\u01B0a r\xF5 tr\u1EA1ng th\xE1i b\xE1nh xe.",
    "live.offline": "Hi\u1EC7n kh\xF4ng k\u1EBFt n\u1ED1i \u0111\u01B0\u1EE3c b\xE1nh xe",
    "live.waiting": "\u0110ang ki\u1EC3m tra b\xE1nh xe",
    "live.speed": "T\u1ED1c \u0111\u1ED9",
    "live.distance": "Qu\xE3ng \u0111\u01B0\u1EDDng",
    "live.block": "Kh\u1ED1i",
    "live.festival": "L\u1EC5 h\u1ED9i r\u01B0\u01A1ng v\xE0ng \u0111\u1EBFn {t}",
    "live.earned": "{n}/300 H\u1EA1t t\u1EEB vi\u1EC7c ch\u1EA1y trong gi\u1EDD n\xE0y",
    "live.gentle": "Squeektoshi ch\u1EA1y khi n\xF3 mu\u1ED1n. Kh\xF4ng c\xF3 g\xEC \u1EDF \u0111\xE2y th\xFAc \xE9p n\xF3.",
    "chest.got": "+{n} H\u1EA1t",
    "chest.item": "v\xE0 m\u1ED9t {item}",
    "chest.normal": "R\u01B0\u01A1ng h\u1EA1t",
    "chest.golden": "R\u01B0\u01A1ng v\xE0ng",
    "chest.bonus": "R\u01B0\u01A1ng th\u01B0\u1EDFng kh\u1ED1i",
    "err.noSeeds": "Ch\u01B0a \u0111\u1EE7 H\u1EA1t.",
    "err.owned": "B\u1EA1n \u0111\xE3 c\xF3 r\u1ED3i.",
    "quest.open5": "M\u1EDF 5 r\u01B0\u01A1ng",
    "quest.golden1": "T\xECm m\u1ED9t r\u01B0\u01A1ng v\xE0ng",
    "quest.runOnline": "Tr\u1EF1c tuy\u1EBFn khi b\xE1nh xe ch\u1EA1y",
    "quest.feed2": "Cho th\xFA c\u01B0ng \u0103n hai l\u1EA7n",
    "quest.reward": "+20 H\u1EA1t, +15 XP",
    "quest.done": "Xong",
    "ach.title": "Th\xE0nh t\xEDch",
    "ach.count": "M\u1EDF kh\xF3a {n}/{m}",
    "log.chest": "M\u1EDF r\u01B0\u01A1ng: +{n} H\u1EA1t",
    "log.golden": "M\u1EDF r\u01B0\u01A1ng v\xE0ng: +{n} H\u1EA1t",
    "log.run": "Ch\u1EA1y c\xF9ng Squeektoshi: +{n} H\u1EA1t",
    "log.block": "Kh\u1ED1i Squeek m\u1EDBi: s\u1EAFp c\xF3 r\u01B0\u01A1ng th\u01B0\u1EDFng",
    "log.festival": "K\u1EF7 l\u1EE5c b\xE1nh xe m\u1EDF l\u1EC5 h\u1ED9i r\u01B0\u01A1ng v\xE0ng",
    "share.text": "\u0110\xE2y l\xE0 {name}, Squeek Pal c\u1EA5p {stage} c\u1EE7a t\xF4i. N\xF3 ch\u1EA1y c\xF9ng Squeektoshi, ch\xFA hamster th\u1EADt v\u1EADn h\xE0nh Squeekchain.",
    "card.tagline": "Ch\u1EA1y c\xF9ng Squeektoshi tr\xEAn Squeekchain",
    "privacy": "R\u01B0\u01A1ng ch\u1EC9 \u0111\u1ECDc ch\u1EEF hi\u1EC3n th\u1ECB c\u1EE7a b\xE0i \u0111\u0103ng, ngay tr\xEAn m\xE1y b\u1EA1n. Kh\xF4ng \u0111\u0103ng, kh\xF4ng th\xEDch, kh\xF4ng g\u1EEDi g\xEC \u0111i.",
    "item.sunflower": "H\u1EA1t h\u01B0\u1EDBng d\u01B0\u01A1ng",
    "item.carrot": "L\xE1t c\xE0 r\u1ED1t",
    "item.yogurt": "Gi\u1ECDt s\u1EEFa chua",
    "item.chew": "Que g\u1EB7m",
    "item.ball": "B\xF3ng c\u1ECF",
    "item.tunnel": "\u0110\u01B0\u1EDDng h\u1EA7m",
    "item.acorn": "M\u0169 h\u1EA1t d\u1EBB",
    "item.beanie": "M\u0169 len xanh",
    "item.party": "M\u0169 ti\u1EC7c",
    "item.crown": "V\u01B0\u01A1ng mi\u1EC7n nh\u1ECF",
    "item.mint": "B\xE1nh xe b\u1EA1c h\xE0",
    "item.sunset": "B\xE1nh xe ho\xE0ng h\xF4n",
    "item.golden": "B\xE1nh xe v\xE0ng",
    "ach.firstChest": "R\u01B0\u01A1ng \u0111\u1EA7u ti\xEAn",
    "ach.chests10": "10 r\u01B0\u01A1ng",
    "ach.chests50": "50 r\u01B0\u01A1ng",
    "ach.chests100": "100 r\u01B0\u01A1ng",
    "ach.firstGolden": "T\xECm th\u1EA5y v\xE0ng",
    "ach.golden5": "5 r\u01B0\u01A1ng v\xE0ng",
    "ach.firstFeed": "B\u1EEFa \u0103n \u0111\u1EA7u ti\xEAn",
    "ach.feeds25": "25 b\u1EEFa \u0103n",
    "ach.plays25": "25 l\u1EA7n ch\u01A1i",
    "ach.cleans10": "10 l\u1EA7n t\u1EAFm",
    "ach.junior": "L\xEAn Thi\u1EBFu ni\xEAn",
    "ach.adult": "L\xEAn Tr\u01B0\u1EDFng th\xE0nh",
    "ach.legend": "Huy\u1EC1n tho\u1EA1i b\xE1nh xe",
    "ach.firstRunSeed": "Ch\u1EA1y c\xF9ng Squeektoshi",
    "ach.runSeeds500": "500 H\u1EA1t t\u1EEB vi\u1EC7c ch\u1EA1y",
    "ach.firstBuy": "L\u1EA7n mua \u0111\u1EA7u ti\xEAn",
    "ach.allHats": "\u0110\u1EE7 m\u1ECDi m\u0169",
    "ach.firstQuest": "Nhi\u1EC7m v\u1EE5 \u0111\u1EA7u ti\xEAn",
    "ach.quests10": "10 nhi\u1EC7m v\u1EE5",
    "ach.festivalChest": "R\u01B0\u01A1ng l\u1EC5 h\u1ED9i",
    "ach.bonusChest": "R\u01B0\u01A1ng th\u01B0\u1EDFng kh\u1ED1i",
    "ach.firstShare": "\u0110\xE3 chia s\u1EBB th\xFA c\u01B0ng"
  };
  var tables = { en, vi };
  function t(lang, key, vars = {}) {
    const s = tables[lang]?.[key] ?? en[key] ?? key;
    return s.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? ""));
  }
  function fmtNum(lang, n, digits = 0) {
    return n.toLocaleString(lang === "vi" ? "vi-VN" : "en-US", { maximumFractionDigits: digits });
  }

  // shared/rules.ts
  var HOUR = 36e5;
  var MINUTE = 6e4;
  var MAX_DRIFT_MS = 12 * HOUR;
  function mood(stats) {
    const avg = (stats.hunger + stats.happiness + stats.energy + stats.cleanliness) / 4;
    const low = Math.min(stats.hunger, stats.happiness, stats.energy, stats.cleanliness);
    if (avg < 35 || low < 15) return "grumpy";
    if (avg >= 70) return "happy";
    return "ok";
  }
  var STAGES = [
    { id: "pup", xp: 0 },
    { id: "junior", xp: 120 },
    { id: "adult", xp: 450 },
    { id: "legend", xp: 1500 }
  ];
  function stageFor(xp) {
    let s = "pup";
    for (const st of STAGES) if (xp >= st.xp) s = st.id;
    return s;
  }
  function nextStageXp(xp) {
    const next = STAGES.find((s) => s.xp > xp);
    return next ? next.xp : null;
  }
  function isOnline(snap) {
    return (snap.freshness ?? "").toLowerCase() === "online";
  }
  function wheelMode(snap, now) {
    if (snap.reach !== "ok" || now - snap.fetchedAt > 5 * MINUTE) return "unknown";
    if (snap.coreStatus === "ACTIVE" && isOnline(snap)) return "running";
    if (snap.coreStatus === "IDLE") return "idle";
    return "unknown";
  }
  function squeekDay(now) {
    return Math.floor((now - 12 * HOUR) / (24 * HOUR));
  }
  function nextQuestReset(now) {
    return (squeekDay(now) + 1) * 24 * HOUR + 12 * HOUR;
  }
  var QUEST_GOALS = { open5: 5, golden1: 1, runOnline: 1, feed2: 2 };
  var QUEST_ORDER = ["open5", "golden1", "runOnline", "feed2"];
  function questsForDay(day) {
    const rest = (day % 4 + 4) % 4;
    return QUEST_ORDER.filter((_, i) => i !== rest).map((id) => ({ id, progress: 0, goal: QUEST_GOALS[id], done: false }));
  }

  // shared/card.ts
  function drawCard(canvas, s) {
    const lang = s.settings.lang;
    canvas.width = 1200;
    canvas.height = 630;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#fffaf2";
    ctx.fillRect(0, 0, 1200, 630);
    ctx.fillStyle = "#f6ecdc";
    ctx.fillRect(0, 470, 1200, 160);
    ctx.fillStyle = "#e3d3bb";
    for (let x = 0; x < 1200; x += 30) ctx.fillRect(x, 470, 15, 8);
    ctx.save();
    const scale = 16;
    ctx.translate(60, 470 - SPRITE_H * scale + 10);
    ctx.scale(scale, scale);
    drawPal(ctx, { pose: "run", frame: 1, hat: s.pet.hat, wheel: s.pet.wheel, mood: mood(s.pet.stats) });
    ctx.restore();
    void SPRITE_W;
    const sys = "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif";
    const fitText = (text, y, startSize, weight = 400) => {
      let size = startSize;
      do {
        ctx.font = `${weight} ${size}px ${sys}`;
      } while (ctx.measureText(text).width > 600 && --size > 18);
      ctx.fillText(text, 560, y);
    };
    ctx.fillStyle = "#2b1d14";
    fitText(s.pet.name, 150, 76, 700);
    ctx.fillStyle = "#6b5544";
    fitText(`${t(lang, `stage.${stageFor(s.pet.xp)}`)} \xB7 ${s.pet.xp} ${t(lang, "label.xp")} \xB7 ${s.seeds} ${t(lang, "label.seeds")}`, 205, 36);
    const stats = ["hunger", "happiness", "energy", "cleanliness"];
    stats.forEach((k, i) => {
      const y = 260 + i * 56;
      ctx.fillStyle = "#2b1d14";
      ctx.font = `400 28px ${sys}`;
      ctx.fillText(t(lang, `stat.${k}`), 560, y + 24);
      ctx.fillStyle = "#e3d3bb";
      ctx.fillRect(800, y, 320, 28);
      ctx.fillStyle = "#a8481a";
      ctx.fillRect(800, y, Math.round(320 * s.pet.stats[k] / 100), 28);
    });
    ctx.fillStyle = "#2b1d14";
    ctx.font = `700 40px ${sys}`;
    ctx.fillText("Squeek Pal", 560, 560);
    ctx.fillStyle = "#6b5544";
    fitText(t(lang, "card.tagline"), 600, 26);
  }
  function downloadCard(doc, s) {
    const c = doc.createElement("canvas");
    drawCard(c, s);
    c.toBlob((blob) => {
      if (!blob) return;
      const a = doc.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `squeek-pal-${s.pet.name.toLowerCase().replace(/[^a-z0-9]+/g, "-") || "card"}.png`;
      doc.body.append(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 5e3);
    }, "image/png");
  }

  // shared/game.ts
  var ACHIEVEMENTS = [
    "firstChest",
    "chests10",
    "chests50",
    "chests100",
    "firstGolden",
    "golden5",
    "firstFeed",
    "feeds25",
    "plays25",
    "cleans10",
    "junior",
    "adult",
    "legend",
    "firstRunSeed",
    "runSeeds500",
    "firstBuy",
    "allHats",
    "firstQuest",
    "quests10",
    "festivalChest",
    "bonusChest",
    "firstShare"
  ];
  function isRunning(s, now) {
    return wheelMode(s.sync, now) === "running";
  }
  function festivalOn(s, now) {
    return s.festival.until > now;
  }

  // shared/share.ts
  function intentUrl(text, url) {
    const q = new URLSearchParams({ text });
    if (url) q.set("url", url);
    return `https://x.com/intent/post?${q.toString()}`;
  }

  // shared/state.ts
  var STORAGE_KEY = "squeekpal";
  function emptySnapshot() {
    return {
      fetchedAt: 0,
      coreStatus: null,
      freshness: null,
      rpmMilli: null,
      speedMmPerSecond: null,
      distanceMm: null,
      cumulativeWorkUnits: null,
      blockHeight: null,
      blockProgress: null,
      reach: "never",
      retryAfter: 0
    };
  }
  function defaultState(now, lang = "en") {
    return {
      version: 2,
      createdAt: now,
      lastTick: now,
      pet: {
        name: "Pip",
        stats: { hunger: 80, happiness: 80, energy: 80, cleanliness: 80 },
        xp: 0,
        hat: null,
        wheel: null
      },
      seeds: 10,
      inventory: { sunflower: 2 },
      owned: [],
      chests: { seenSinceLast: 0, placedTimes: [], pending: [], opened: 0, goldenOpened: 0 },
      earn: { hourStart: now, earnedThisHour: 0, totalRunSeeds: 0 },
      counters: { feeds: 0, plays: 0, cleans: 0, shares: 0, questsDone: 0, seedsTotal: 0 },
      quests: { day: -1, list: [] },
      achievements: [],
      festival: { until: 0, seenIds: [] },
      sync: emptySnapshot(),
      lastXSeen: 0,
      settings: {
        lang,
        chestsOn: true,
        palOn: true,
        minimized: false,
        hiddenPaths: [],
        pos: null
      },
      log: []
    };
  }
  function clampNum(v, lo, hi, fallback) {
    const n = typeof v === "number" && Number.isFinite(v) ? v : fallback;
    return Math.min(hi, Math.max(lo, n));
  }
  function record(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v) ? v : {};
  }
  var list = (v) => Array.isArray(v) ? v : [];
  function sanitizeV2(raw, now) {
    const r = record(raw);
    const s = defaultState(now);
    const time = (v, fallback = 0, hi = now) => clampNum(v, 0, hi, fallback);
    const count = (v, fallback = 0, hi = 1e9) => Math.floor(clampNum(v, 0, hi, fallback));
    const pet = record(r.pet), stats = record(pet.stats);
    s.createdAt = time(r.createdAt, now);
    s.lastTick = time(r.lastTick, now);
    s.lastXSeen = time(r.lastXSeen);
    s.pet.name = typeof pet.name === "string" && pet.name.trim() ? pet.name.trim().slice(0, 16) : s.pet.name;
    for (const k of Object.keys(s.pet.stats)) s.pet.stats[k] = clampNum(stats[k], 0, 100, s.pet.stats[k]);
    s.pet.xp = count(pet.xp);
    for (const slot of ["hat", "wheel"]) {
      const id = pet[slot];
      s.pet[slot] = typeof id === "string" && itemById(id)?.kind === slot ? id : null;
    }
    s.seeds = count(r.seeds, s.seeds);
    if (r.inventory !== void 0 && r.inventory !== null && typeof r.inventory === "object" && !Array.isArray(r.inventory)) {
      const inventory = record(r.inventory);
      s.inventory = Object.fromEntries(ITEMS.filter((i) => i.kind === "food" && Object.hasOwn(inventory, i.id)).map((i) => [i.id, count(inventory[i.id], 0, 1e6)]));
    }
    s.owned = [...new Set(list(r.owned).filter((id) => typeof id === "string" && !!itemById(id) && itemById(id).kind !== "food"))];
    const chests = record(r.chests);
    s.chests.seenSinceLast = count(chests.seenSinceLast);
    s.chests.opened = count(chests.opened);
    s.chests.goldenOpened = count(chests.goldenOpened);
    s.chests.placedTimes = list(chests.placedTimes).filter((v) => typeof v === "number" && Number.isFinite(v) && v >= now - 36e5 && v <= now).slice(-12);
    const chestIds = /* @__PURE__ */ new Set();
    for (const entry of list(chests.pending).slice(-12)) {
      const c = record(entry);
      if (typeof c.id !== "string" || !/^[a-z0-9]{1,64}$/.test(c.id) || chestIds.has(c.id)) continue;
      if (c.kind !== "normal" && c.kind !== "golden" && c.kind !== "bonus") continue;
      if (typeof c.createdAt !== "number" || !Number.isFinite(c.createdAt) || c.createdAt < 0 || c.createdAt > now) continue;
      chestIds.add(c.id);
      s.chests.pending.push({ id: c.id, kind: c.kind, createdAt: c.createdAt });
    }
    const earn = record(r.earn);
    s.earn = { hourStart: time(earn.hourStart, now), earnedThisHour: count(earn.earnedThisHour, 0, 300), totalRunSeeds: count(earn.totalRunSeeds) };
    const counters = record(r.counters);
    for (const k of Object.keys(s.counters)) s.counters[k] = count(counters[k]);
    const quests = record(r.quests);
    if (typeof quests.day === "number" && Number.isInteger(quests.day) && quests.day >= 0 && quests.day <= squeekDay(now)) {
      s.quests.day = quests.day;
      s.quests.list = questsForDay(quests.day).map((q) => {
        const saved = list(quests.list).map(record).find((v) => v.id === q.id);
        const progress = count(saved?.progress, 0, q.goal);
        return { ...q, progress, done: progress >= q.goal };
      });
    }
    s.achievements = ACHIEVEMENTS.filter((id) => list(r.achievements).includes(id));
    const festival = record(r.festival);
    s.festival.until = time(festival.until, 0, now + 36e5);
    s.festival.seenIds = [...new Set(list(festival.seenIds).filter((id) => typeof id === "string" && id.length > 0 && id.length <= 256))].slice(-200);
    const sync = record(r.sync);
    s.sync.fetchedAt = time(sync.fetchedAt);
    s.sync.retryAfter = time(sync.retryAfter, 0, Number.MAX_SAFE_INTEGER);
    s.sync.coreStatus = ["ACTIVE", "IDLE", "COUNTER_FAULT"].includes(sync.coreStatus) ? sync.coreStatus : null;
    s.sync.freshness = typeof sync.freshness === "string" && /^(online|stale|offline|unknown)$/i.test(sync.freshness) ? sync.freshness : null;
    for (const k of ["rpmMilli", "speedMmPerSecond", "distanceMm", "cumulativeWorkUnits", "blockHeight", "blockProgress"]) {
      const v = sync[k];
      s.sync[k] = typeof v === "string" && /^\d+(\.\d+)?$/.test(v) && v.length <= 100 ? v : null;
    }
    s.sync.reach = sync.reach === "ok" || sync.reach === "error" ? sync.reach : "never";
    const settings = record(r.settings);
    s.settings.lang = settings.lang === "vi" ? "vi" : "en";
    for (const k of ["chestsOn", "palOn", "minimized"]) if (typeof settings[k] === "boolean") s.settings[k] = settings[k];
    s.settings.hiddenPaths = [...new Set(list(settings.hiddenPaths).filter((p) => typeof p === "string" && p.startsWith("/") && p.length <= 2048))].slice(-200);
    const pos = record(settings.pos);
    if (typeof pos.x === "number" && Number.isFinite(pos.x) && typeof pos.y === "number" && Number.isFinite(pos.y)) {
      s.settings.pos = { x: count(pos.x, 0, 1e5), y: count(pos.y, 0, 1e5) };
    }
    const logKeys = ["log.chest", "log.golden", "log.run", "log.block", "log.festival"];
    s.log = list(r.log).map(record).filter((l) => typeof l.key === "string" && logKeys.includes(l.key)).slice(0, 12).map((l) => ({ t: time(l.t), key: l.key, ...l.n === void 0 ? {} : { n: count(l.n) } }));
    return s;
  }
  function migrate(raw, now) {
    if (!raw || typeof raw !== "object") return defaultState(now);
    const r = raw;
    if (r.version === 1) {
      const v1 = raw;
      const s = defaultState(now, v1.lang === "vi" ? "vi" : "en");
      s.pet.name = typeof v1.name === "string" && v1.name.trim() ? v1.name.slice(0, 16) : s.pet.name;
      for (const k of Object.keys(s.pet.stats)) {
        s.pet.stats[k] = clampNum(v1.stats?.[k], 0, 100, s.pet.stats[k]);
      }
      s.pet.xp = clampNum(v1.xp, 0, 1e9, 0);
      s.seeds = clampNum(v1.seeds, 0, 1e9, s.seeds);
      if (v1.inventory && typeof v1.inventory === "object") s.inventory = { ...v1.inventory };
      return sanitizeV2(s, now);
    }
    if (r.version === 2) {
      return sanitizeV2(raw, now);
    }
    return defaultState(now);
  }
  function checksum(s) {
    let h = 2166136261;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(36);
  }
  function toB64(s) {
    const bytes = new TextEncoder().encode(s);
    let bin = "";
    for (const b of bytes) bin += String.fromCharCode(b);
    return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function fromB64(s) {
    const pad = s.replace(/-/g, "+").replace(/_/g, "/");
    const bin = atob(pad + "===".slice((pad.length + 3) % 4));
    const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
    return new TextDecoder().decode(bytes);
  }
  function exportCode(state) {
    const { log: _log, sync: _sync, ...rest } = state;
    const body2 = toB64(JSON.stringify(rest));
    return `SQK2.${body2}.${checksum(body2)}`;
  }
  function importCode(code, now) {
    const parts = code.trim().split(".");
    if (parts.length !== 3 || parts[0] !== "SQK2") return null;
    if (checksum(parts[1]) !== parts[2]) return null;
    try {
      const data = JSON.parse(fromB64(parts[1]));
      return migrate(data, now);
    } catch {
      return null;
    }
  }

  // shared/ui.ts
  var THEME_CSS = `
:host, .sp-root {
  --sp-bg: #fffaf2; --sp-surface: #f6ecdc; --sp-fg: #2b1d14; --sp-muted: #6b5544; --sp-line: #e3d3bb;
  --sp-accent: #a8481a; --sp-accent-fg: #ffffff; --sp-good: #2f7d4f; --sp-warn: #9a5b00; --sp-focus: #1d70b8;
  --sp-shadow: 0 1px 2px rgb(43 29 20 / 0.12), 0 6px 20px rgb(43 29 20 / 0.16);
  color-scheme: light;
}
[data-theme="dim"], :host([data-theme="dim"]) {
  --sp-bg: #1e2a36; --sp-surface: #273544; --sp-fg: #f2ece4; --sp-muted: #b9c2cc; --sp-line: #3a4a5b;
  --sp-accent: #f0a35c; --sp-accent-fg: #1a1209; --sp-good: #7fd6a2; --sp-warn: #f5c76b; --sp-focus: #8ec5ff;
  --sp-shadow: 0 1px 2px rgb(0 0 0 / 0.3), 0 6px 20px rgb(0 0 0 / 0.35);
  color-scheme: dark;
}
[data-theme="dark"], :host([data-theme="dark"]) {
  --sp-bg: #111111; --sp-surface: #1c1c1c; --sp-fg: #f2ece4; --sp-muted: #b3aca4; --sp-line: #333333;
  --sp-accent: #f0a35c; --sp-accent-fg: #1a1209; --sp-good: #7fd6a2; --sp-warn: #f5c76b; --sp-focus: #8ec5ff;
  --sp-shadow: 0 1px 2px rgb(0 0 0 / 0.4), 0 6px 20px rgb(0 0 0 / 0.5);
  color-scheme: dark;
}`;
  function esc(s) {
    return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  }
  var STATS = ["hunger", "happiness", "energy", "cleanliness"];
  function statBars(lang, s) {
    return `<dl class="sp-stats">${STATS.map((k) => {
      const v = Math.round(s.pet.stats[k]);
      return `<div class="sp-stat"><dt>${t(lang, `stat.${k}`)}</dt><dd><span class="sp-bar" role="meter" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${v}" aria-label="${t(lang, `stat.${k}`)}"><span style="inline-size:${v}%" class="${v < 25 ? "low" : ""}"></span></span><span class="sp-num">${v}</span></dd></div>`;
    }).join("")}</dl>`;
  }
  function bigFmt(lang, v, div, digits) {
    if (v === null || !/^-?\d+(\.\d+)?$/.test(v)) return null;
    return fmtNum(lang, Number(v) / div, digits);
  }
  function liveStrip(lang, s, now) {
    const snap = s.sync;
    const mode = wheelMode(snap, now);
    let headline;
    let cls = "unknown";
    if (snap.reach === "never") headline = t(lang, "live.waiting");
    else if (snap.reach === "error") {
      headline = t(lang, "live.offline");
      cls = "offline";
    } else if (mode === "running") {
      headline = t(lang, "live.running");
      cls = "running";
    } else if (mode === "idle") {
      headline = t(lang, "live.idle");
      cls = "idle";
    } else headline = t(lang, "live.unknown");
    const speed = bigFmt(lang, snap.speedMmPerSecond, 1, 0);
    const dist = bigFmt(lang, snap.distanceMm, 1e3, 1);
    const block = bigFmt(lang, snap.blockHeight, 1, 0);
    const fest = festivalOn(s, now) ? `<p class="sp-fest">${t(lang, "live.festival", { t: new Date(s.festival.until).toLocaleTimeString(lang === "vi" ? "vi-VN" : "en-US", { hour: "2-digit", minute: "2-digit" }) })}</p>` : "";
    const earned = isRunning(s, now) ? `<p class="sp-small">${t(lang, "live.earned", { n: s.earn.earnedThisHour })}</p>` : "";
    return `<section class="sp-live sp-live-${cls}" aria-label="${t(lang, "live.title")}">
    <h2 class="sp-live-title"><span class="sp-dot" aria-hidden="true"></span>${t(lang, "live.title")}</h2>
    <p class="sp-live-head" role="status">${headline}</p>
    <dl class="sp-live-nums">
      <div><dt>${t(lang, "live.speed")}</dt><dd>${speed === null ? "\u2013" : `${speed} mm/s`}</dd></div>
      <div><dt>${t(lang, "live.distance")}</dt><dd>${dist === null ? "\u2013" : `${dist} m`}</dd></div>
      <div><dt>${t(lang, "live.block")}</dt><dd>${block === null ? "\u2013" : `#${block}`}</dd></div>
    </dl>${fest}${earned}
  </section>`;
  }

  // shared/panel.ts
  var TABS = ["pet", "shop", "wardrobe", "quests", "settings"];
  var PANEL_CSS = `${THEME_CSS}
.sp-root { font: 400 14px/1.45 system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans", Arial, sans-serif; color: var(--sp-fg); background: var(--sp-bg); }
.sp-root * { box-sizing: border-box; }
.sp-root h2, .sp-root h3, .sp-root p, .sp-root dl, .sp-root dd, .sp-root ul { margin: 0; padding: 0; }
.sp-root ul { list-style: none; }
.sp-root button, .sp-root input, .sp-root textarea, .sp-root select { font: inherit; color: inherit; }
.sp-root :focus-visible { outline: 2px solid var(--sp-focus); outline-offset: 2px; }
.sp-btn { min-block-size: 36px; padding: 6px 14px; border-radius: 10px; border: 1px solid var(--sp-line); background: var(--sp-surface); cursor: pointer; transition: scale 150ms cubic-bezier(0.2, 0, 0, 1), background-color 150ms; }
.sp-btn:active { scale: 0.96; }
.sp-btn[disabled] { opacity: 0.55; cursor: not-allowed; }
.sp-btn.primary { background: var(--sp-accent); color: var(--sp-accent-fg); border-color: transparent; font-weight: 600; }
.sp-row { display: flex; flex-wrap: wrap; gap: 8px; }
.sp-tabs { display: flex; flex-wrap: wrap; gap: 4px; padding: 8px; border-block-end: 1px solid var(--sp-line); }
.sp-tab { min-block-size: 36px; padding: 6px 8px; border: 0; border-radius: 8px; background: transparent; cursor: pointer; white-space: nowrap; }
.sp-tab[aria-selected="true"] { background: var(--sp-surface); font-weight: 600; }
.sp-body { padding: 12px; display: grid; gap: 16px; }
.sp-card { display: grid; grid-template-columns: auto 1fr; gap: 12px; align-items: center; }
.sp-card canvas { inline-size: 84px; block-size: 78px; image-rendering: pixelated; background: var(--sp-surface); border-radius: 12px; }
.sp-name { font-size: 18px; font-weight: 600; line-height: 1.2; }
.sp-small { font-size: 12px; color: var(--sp-muted); }
.sp-seeds { font-weight: 600; font-variant-numeric: tabular-nums; }
.sp-stats { display: grid; gap: 6px; }
.sp-stat { display: grid; grid-template-columns: 92px 1fr; align-items: center; gap: 8px; }
.sp-stat dt { color: var(--sp-muted); }
.sp-stat dd { display: flex; align-items: center; gap: 8px; }
.sp-bar { flex: 1; block-size: 8px; border-radius: 4px; background: var(--sp-line); overflow: hidden; }
.sp-bar > span { display: block; block-size: 100%; background: var(--sp-good); }
.sp-bar > span.low { background: var(--sp-warn); }
.sp-num { inline-size: 3ch; text-align: end; font-variant-numeric: tabular-nums; }
.sp-live { padding: 10px 12px; border-radius: 12px; background: var(--sp-surface); display: grid; gap: 6px; }
.sp-live-title { font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 6px; }
.sp-dot { inline-size: 8px; block-size: 8px; border-radius: 50%; background: var(--sp-muted); }
.sp-live-running .sp-dot { background: var(--sp-good); }
.sp-live-offline .sp-dot { background: var(--sp-warn); }
.sp-live-nums { display: flex; flex-wrap: wrap; gap: 4px 16px; font-variant-numeric: tabular-nums; }
.sp-live-nums dt { font-size: 12px; color: var(--sp-muted); }
.sp-fest { font-weight: 600; color: var(--sp-warn); }
.sp-list { display: grid; gap: 8px; }
.sp-item { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 8px 10px; border-radius: 10px; background: var(--sp-surface); }
.sp-item > div { min-inline-size: 0; }
.sp-h { font-size: 14px; font-weight: 600; }
.sp-section { display: grid; gap: 8px; }
.sp-q { display: grid; gap: 4px; }
.sp-ach { display: flex; flex-wrap: wrap; gap: 6px; }
.sp-ach li { padding: 2px 8px; border-radius: 999px; background: var(--sp-surface); font-size: 12px; color: var(--sp-muted); }
.sp-ach li.got { color: var(--sp-fg); font-weight: 600; }
.sp-field { display: grid; gap: 4px; }
.sp-field input, .sp-field textarea, .sp-field select { inline-size: 100%; padding: 8px; border-radius: 8px; border: 1px solid var(--sp-line); background: var(--sp-bg); }
.sp-field textarea { min-block-size: 64px; font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 12px; }
.sp-check { display: flex; gap: 8px; align-items: center; min-block-size: 32px; cursor: pointer; }
.sp-check input { inline-size: 18px; block-size: 18px; accent-color: var(--sp-accent); }
.sp-msg { min-block-size: 1.45em; }
`;
  function fxMessage(lang, fx) {
    if (fx.error === "noSeeds") return t(lang, "err.noSeeds");
    if (fx.error === "owned") return t(lang, "err.owned");
    if (fx.opened) {
      const item = fx.opened.item ? ` ${t(lang, "chest.item", { item: t(lang, `item.${fx.opened.item}`) })}` : "";
      return `${t(lang, "chest.got", { n: fx.opened.seeds })}${item}`;
    }
    if (fx.achievements?.length) return `${t(lang, "ach.title")}: ${fx.achievements.map((a) => t(lang, `ach.${a}`)).join(", ")}`;
    return "";
  }
  function mountPanel(root, opts) {
    const { store } = opts;
    let tab = opts.initialTab ?? "pet";
    let msg = "";
    const doc = root.ownerDocument;
    root.classList.add("sp-root");
    const render = () => {
      const s = store.get();
      if (!s) return;
      const lang = s.settings.lang;
      root.dataset.lang = lang;
      const focusKey = doc.activeElement?.dataset?.k ?? root.getRootNode().activeElement?.getAttribute("data-k");
      const now = Date.now();
      root.innerHTML = `
      <div class="sp-tabs" role="tablist" aria-label="Squeek Pal">
        ${TABS.map((id) => `<button class="sp-tab" role="tab" id="sp-tab-${id}" data-k="tab-${id}" data-tab="${id}" aria-selected="${id === tab}" aria-controls="sp-tabpanel" tabindex="${id === tab ? 0 : -1}">${t(lang, `tab.${id}`)}</button>`).join("")}
      </div>
      <div class="sp-body" id="sp-tabpanel" role="tabpanel" aria-labelledby="sp-tab-${tab}">
        ${body(tab, s, lang, now)}
        <p class="sp-msg sp-small" role="status">${esc(msg)}</p>
      </div>`;
      const slot = root.querySelector("[data-pal-slot]");
      if (slot) {
        slot.replaceWith(palCanvas(doc, 3, { pose: "sit", frame: 0, hat: s.pet.hat, wheel: s.pet.wheel, mood: mood(s.pet.stats) }));
      }
      if (focusKey) root.querySelector(`[data-k="${focusKey}"]`)?.focus();
    };
    const run = async (action) => {
      const fx = await store.dispatch(action);
      const s = store.get();
      msg = s ? fxMessage(s.settings.lang, fx) : "";
      render();
    };
    const onClick = async (e) => {
      const el = e.target.closest("[data-act],[data-tab]");
      if (!el || !root.contains(el)) return;
      const s = store.get();
      if (!s) return;
      const lang = s.settings.lang;
      if (el.dataset.tab) {
        tab = el.dataset.tab;
        opts.onTabChange?.(tab);
        msg = "";
        render();
        return;
      }
      const act = el.dataset.act;
      const id = el.dataset.id ?? "";
      if (act === "feed" || act === "play" || act === "clean") return run({ type: act });
      if (act === "buy") return run({ type: "buy", id });
      if (act === "equip") return run({ type: "equip", id: id || null, slot: el.dataset.slot });
      if (act === "share") {
        const text = t(lang, "share.text", { name: s.pet.name, stage: t(lang, `stage.${stageFor(s.pet.xp)}`) });
        const url = intentUrl(text, opts.shareUrl);
        (opts.open ?? ((u) => window.open(u, "_blank", "noopener")))(url);
        return run({ type: "shared" });
      }
      if (act === "card") return downloadCard(doc, s);
      if (act === "export") {
        const code = exportCode(s);
        const ta = root.querySelector("#sp-code");
        if (ta) ta.value = code;
        try {
          await navigator.clipboard.writeText(code);
          msg = t(lang, "set.copied");
        } catch {
          msg = "";
          ta?.select();
        }
        const m = root.querySelector(".sp-msg");
        if (m) m.textContent = msg;
        return;
      }
      if (act === "import") {
        const ta = root.querySelector("#sp-code");
        const next = ta ? importCode(ta.value, Date.now()) : null;
        if (!next) {
          msg = t(lang, "set.importBad");
          ta?.setAttribute("aria-invalid", "true");
          const m = root.querySelector(".sp-msg");
          if (m) m.textContent = msg;
          ta?.focus();
          return;
        }
        await store.dispatch({ type: "replace", state: next });
        msg = t(next.settings.lang, "set.importOk");
        render();
        return;
      }
      if (act === "unhide") return run({ type: "settings", patch: { hiddenPaths: [] } });
    };
    const onChange = (e) => {
      const el = e.target;
      if (el.name === "palOn" || el.name === "chestsOn") void run({ type: "settings", patch: { [el.name]: el.checked } });
      if (el.name === "lang") void run({ type: "settings", patch: { lang: el.value } });
      if (el.name === "petName") void run({ type: "rename", name: el.value });
    };
    const onKey = (e) => {
      const el = e.target;
      if (!el.dataset.tab || e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
      const i = TABS.indexOf(el.dataset.tab);
      tab = TABS[(i + (e.key === "ArrowRight" ? 1 : TABS.length - 1)) % TABS.length];
      opts.onTabChange?.(tab);
      msg = "";
      render();
      root.querySelector(`[data-tab="${tab}"]`)?.focus();
    };
    root.addEventListener("click", onClick);
    root.addEventListener("change", onChange);
    root.addEventListener("keydown", onKey);
    const unsub = store.subscribe(() => {
      const active = root.getRootNode().activeElement;
      if (active && root.contains(active) && (active.tagName === "TEXTAREA" || active.tagName === "INPUT")) return;
      render();
    });
    const timer = window.setInterval(render, 3e4);
    render();
    return () => {
      unsub();
      clearInterval(timer);
      root.removeEventListener("click", onClick);
      root.removeEventListener("change", onChange);
      root.removeEventListener("keydown", onKey);
    };
    void nextQuestReset;
  }
  function body(tab, s, lang, now) {
    const nxt = nextStageXp(s.pet.xp);
    const card = `<div class="sp-card"><span data-pal-slot></span><div>
      <p class="sp-name">${esc(s.pet.name)}</p>
      <p class="sp-small">${t(lang, `stage.${stageFor(s.pet.xp)}`)} \xB7 ${t(lang, `mood.${mood(s.pet.stats)}`)} \xB7 ${esc(String(s.pet.xp))} ${t(lang, "label.xp")}</p>
      <p class="sp-small">${nxt === null ? t(lang, "label.maxStage") : t(lang, "label.nextStage", { n: nxt - s.pet.xp })}</p>
      <p class="sp-seeds">${esc(String(s.seeds))} ${t(lang, "label.seeds")}</p>
    </div></div>`;
    if (tab === "pet") {
      const food = itemsOfKind("food").map((f) => `${t(lang, `item.${f.id}`)} \xD7${esc(String(s.inventory[f.id] ?? 0))}`).join(", ");
      return `${card}${liveStrip(lang, s, now)}${statBars(lang, s)}
      <div class="sp-row">
        <button class="sp-btn primary" data-act="feed" data-k="feed">${t(lang, "act.feed")}</button>
        <button class="sp-btn" data-act="play" data-k="play">${t(lang, "act.play")}</button>
        <button class="sp-btn" data-act="clean" data-k="clean">${t(lang, "act.clean")}</button>
      </div>
      <p class="sp-small">${t(lang, "label.inventory")}: ${food}</p>
      <div class="sp-row">
        <button class="sp-btn" data-act="share" data-k="share">${t(lang, "act.share")}</button>
        <button class="sp-btn" data-act="card" data-k="card">${t(lang, "act.card")}</button>
      </div>`;
    }
    if (tab === "shop") {
      const kinds = ["food", "toy", "hat", "wheel"];
      return `<p class="sp-seeds">${esc(String(s.seeds))} ${t(lang, "label.seeds")}</p>${kinds.map(
        (k) => `<section class="sp-section"><h3 class="sp-h">${t(lang, `kind.${k}`)}</h3><ul class="sp-list">${itemsOfKind(k).map((it) => {
          const owned = it.kind !== "food" && s.owned.includes(it.id);
          const name = t(lang, `item.${it.id}`);
          const sub = it.kind === "food" ? esc(t(lang, "label.have", { n: s.inventory[it.id] ?? 0 })) : owned ? t(lang, "label.owned") : "";
          return `<li class="sp-item"><div><p>${name}</p><p class="sp-small">${t(lang, "label.price", { n: it.price })}${sub ? ` \xB7 ${sub}` : ""}</p></div>
              <button class="sp-btn" data-act="buy" data-id="${it.id}" data-k="buy-${it.id}" ${owned ? "disabled" : ""} aria-label="${t(lang, "act.buy")} ${name}">${t(lang, "act.buy")}</button></li>`;
        }).join("")}</ul></section>`
      ).join("")}`;
    }
    if (tab === "wardrobe") {
      const slot = (k) => {
        const owned = ITEMS.filter((i) => i.kind === k && s.owned.includes(i.id));
        const none = k === "hat" ? t(lang, "label.noHat") : t(lang, "label.noWheel");
        const rows = [{ id: "", name: none }, ...owned.map((i) => ({ id: i.id, name: t(lang, `item.${i.id}`) }))];
        return `<section class="sp-section"><h3 class="sp-h">${t(lang, `kind.${k}`)}</h3><ul class="sp-list">${rows.map((r) => {
          const on = (s.pet[k] ?? "") === r.id;
          return `<li class="sp-item"><p>${r.name}${on ? ` \xB7 <span class="sp-small">${t(lang, "label.wearing")}</span>` : ""}</p>
            <button class="sp-btn" data-act="equip" data-slot="${k}" data-id="${r.id}" data-k="eq-${k}-${r.id}" ${on ? "disabled" : ""} aria-label="${t(lang, "act.equip")} ${r.name}">${t(lang, "act.equip")}</button></li>`;
        }).join("")}</ul></section>`;
      };
      return `${card}${slot("hat")}${slot("wheel")}`;
    }
    if (tab === "quests") {
      return `<section class="sp-section"><h3 class="sp-h">${t(lang, "tab.quests")}</h3><p class="sp-small">${t(lang, "label.questReset")}</p>
      <ul class="sp-list">${s.quests.list.map(
        (q) => `<li class="sp-item"><div class="sp-q"><p>${t(lang, `quest.${q.id}`)}</p><p class="sp-small">${t(lang, "quest.reward")}</p></div>
          <p class="sp-num" style="inline-size:auto">${q.done ? t(lang, "quest.done") : `${esc(String(q.progress))}/${esc(String(q.goal))}`}</p></li>`
      ).join("")}</ul></section>
      <section class="sp-section"><h3 class="sp-h">${t(lang, "ach.title")}</h3><p class="sp-small">${t(lang, "ach.count", { n: s.achievements.length, m: ACHIEVEMENTS.length })}</p>
      <ul class="sp-ach">${ACHIEVEMENTS.map((a) => `<li class="${s.achievements.includes(a) ? "got" : ""}">${s.achievements.includes(a) ? "\u2713 " : ""}${t(lang, `ach.${a}`)}</li>`).join("")}</ul></section>`;
    }
    return `<div class="sp-field"><label for="sp-name">${t(lang, "label.name")}</label><input id="sp-name" name="petName" maxlength="16" value="${esc(s.pet.name)}" autocomplete="off"></div>
    <div class="sp-field"><label for="sp-lang">${t(lang, "label.lang")}</label><select id="sp-lang" name="lang" data-k="lang"><option value="en" ${lang === "en" ? "selected" : ""}>English</option><option value="vi" ${lang === "vi" ? "selected" : ""}>Ti\u1EBFng Vi\u1EC7t</option></select></div>
    <label class="sp-check"><input type="checkbox" name="palOn" data-k="palOn" ${s.settings.palOn ? "checked" : ""}>${t(lang, "set.palOn")}</label>
    <label class="sp-check"><input type="checkbox" name="chestsOn" data-k="chestsOn" ${s.settings.chestsOn ? "checked" : ""}>${t(lang, "set.chestsOn")}</label>
    ${s.settings.hiddenPaths.length ? `<div class="sp-row"><p class="sp-small">${t(lang, "set.hidden", { n: s.settings.hiddenPaths.length })}</p><button class="sp-btn" data-act="unhide" data-k="unhide">${t(lang, "set.unhide")}</button></div>` : ""}
    <div class="sp-field"><label for="sp-code">${t(lang, "label.saveCode")}</label><textarea id="sp-code" spellcheck="false" placeholder="SQK2.\u2026"></textarea></div>
    <div class="sp-row"><button class="sp-btn" data-act="export" data-k="export">${t(lang, "act.export")}</button><button class="sp-btn" data-act="import" data-k="import">${t(lang, "act.import")}</button></div>
    <p class="sp-small">${t(lang, "privacy")}</p>`;
  }

  // extension/chromeStore.ts
  async function chromeStore() {
    let state = null;
    const subs = /* @__PURE__ */ new Set();
    const got = await chrome.storage.local.get(STORAGE_KEY);
    if (got[STORAGE_KEY]) state = migrate(got[STORAGE_KEY], Date.now());
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes[STORAGE_KEY]?.newValue) return;
      state = migrate(changes[STORAGE_KEY].newValue, Date.now());
      for (const fn of subs) fn(state);
    });
    const store = {
      get: () => state,
      async dispatch(action) {
        try {
          const fx = await chrome.runtime.sendMessage({ type: "squeekpal:dispatch", action });
          const fresh = await chrome.storage.local.get(STORAGE_KEY);
          if (fresh[STORAGE_KEY]) {
            state = migrate(fresh[STORAGE_KEY], Date.now());
            for (const fn of subs) fn(state);
          }
          return fx ?? {};
        } catch {
          return {};
        }
      },
      subscribe(fn) {
        subs.add(fn);
        return () => subs.delete(fn);
      }
    };
    if (!state) await store.dispatch({ type: "tick" });
    return store;
  }

  // extension/siteUrl.ts
  var SITE_URL = true ? "" : "";

  // extension/popup.ts
  async function main() {
    const style = document.createElement("style");
    style.textContent = PANEL_CSS;
    document.head.append(style);
    const root = document.getElementById("app");
    const dark = matchMedia("(prefers-color-scheme: dark)");
    const theme = () => root.setAttribute("data-theme", dark.matches ? "dim" : "light");
    theme();
    dark.addEventListener("change", theme);
    const store = await chromeStore();
    const initialTab = document.body.dataset.tab ?? "pet";
    mountPanel(root, { store, shareUrl: SITE_URL, initialTab });
    const sync = () => {
      const lang = store.get()?.settings.lang ?? "en";
      document.documentElement.lang = lang;
    };
    sync();
    store.subscribe(sync);
  }
  void main();
})();
